/**
 * 
 */
/**
 * 
 */
module assignment_1 {
	requires org.junit.jupiter.api;
	requires junit;
	requires java.sql;
	requires gson;
	
	 opens ict4315.parking.common to gson;
	 opens ict4315.parking.protocol to gson;
}