package ict4315.charges.decorator.factory;

import java.time.DayOfWeek;
import java.time.LocalDateTime;

import ict4315.charges.decorator.CompactCarDiscountDecorator;
import ict4315.charges.decorator.FlatRateCalculator;
import ict4315.charges.decorator.GraduationSurchargeDecorator;
import ict4315.charges.decorator.ParkingChargeCalculator;
import ict4315.charges.decorator.WeekendFreeDecorator;
import ict4315_assignment_1.CarType;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;

/**
 * A factory to assemble a chain of ParkingChargeCalculator decorators
 * based on car type, date, and other conditions.
 */

public class ParkingChargeCalculatorFactory {

    /**
     * Builds a ParkingChargeCalculator with decorators applied in order,
     * depending on the permit and date logic.
     *
     * @param lot the parking lot
     * @param permit the vehicle's parking permit
     * @param start the parking start time
     * @param end the parking end time
     * @return decorated ParkingChargeCalculator
     */
	
	public ParkingChargeCalculator createCalculator(ParkingLot lot, ParkingPermit permit, 
			LocalDateTime start, LocalDateTime end) {
		
        ParkingChargeCalculator calculator  = new FlatRateCalculator(10.0, "USD");

        // Compose decorators conditionally
        if (permit.getCar().getType() == CarType.COMPACT) {
        	calculator  = new CompactCarDiscountDecorator(calculator);
        }
        if (isWeekend(start)) {
        	calculator  = new WeekendFreeDecorator(calculator);
        }
        if (isGraduationDay(start)) {
        	calculator  = new GraduationSurchargeDecorator(calculator);
        }

        return calculator ;
    }
	
    /**
     * Determines if a given date falls on a weekend (Saturday or Sunday).
     *
     * @param dateTime the date to evaluate
     * @return {@code true} if weekend, {@code false} otherwise
     */
    private boolean isWeekend(LocalDateTime dateTime) {
    	DayOfWeek day = dateTime.getDayOfWeek();
        return day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY;    }

    /**
     * Determines if the given date is within the defined graduation period.
     *
     * @param dateTime the date to evaluate
     * @return {@code true} if during graduation, {@code false} otherwise
     */
    private boolean isGraduationDay(LocalDateTime dateTime) {
    	int year = dateTime.getYear();
        LocalDateTime gradStart = LocalDateTime.of(year, 5, 9, 0, 0);
        LocalDateTime gradEnd = LocalDateTime.of(year, 5, 10, 23, 59);
        return !dateTime.isBefore(gradStart) && !dateTime.isAfter(gradEnd);
    }
	
}
