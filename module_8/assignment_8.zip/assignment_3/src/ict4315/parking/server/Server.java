package ict4315.parking.server;

import java.io.*;
import java.net.*;
import java.util.Map;
import java.util.Properties;

import com.google.gson.Gson;
import ict4315.parking.common.CommandMessage;
import ict4315.parking.protocol.ParkingRequest;
import ict4315.parking.protocol.ParkingResponse;

/**
 * The {@code Server} class listens on a specified port (default 8080) for client connections.
 * It uses a multi-threaded approach where each incoming client is handled by a ClientHandler.
 * 
 * The server expects client messages formatted as JSON strings using the
 * ParkingRequest protocol and responds with JSON-encoded ParkingResponse objects.
 *
 * This approach replaces the older line-by-line custom protocol with a standardized,
 * extensible, and robust JSON-based messaging system.
 * 
 * Example JSON request:
 *   "command": "CUSTOMER",
 *   "properties": {
 *     "firstname": "Rob",
 *     "lastname": "Smith",
 *     "email": "rob@example.com"
 *   }
 * }
 *
 * Example JSON response:
 *   "statusCode": 0,
 *   "message": "Customer registered successfully"
 */
public class Server {
	
    /**
     * Main entry point of the server application.
     * Listens for connections and spawns a new ClientHandler thread for each client.
     *
     * @param args command-line arguments (not used)
     */
	
	private static final int PORT = 8080; // Chosen port

	
    public static void main(String[] args) {
    	
        Server server = new Server();
        server.start();
    }
        
        // Start the server socket and accept connections
        public void start() {
            try (ServerSocket serverSocket = new ServerSocket(PORT)) {
                System.out.println("Server listening on port " + PORT);

                while (true) {
                    Socket clientSocket = serverSocket.accept();
                    System.out.println("Client connected: " + clientSocket.getInetAddress());
                    new Thread(new ClientHandler(clientSocket)).start();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    // Handles a ParkingRequest and returns a ParkingResponse (can be tested)
    public ParkingResponse handleRequest(ParkingRequest request) {
        if (request == null || request.getCommand() == null) {
            return new ParkingResponse(1, "Invalid request");
        }

        String command = request.getCommand().toUpperCase();

        switch (command) {
            case "CUSTOMER":
                return handleCustomer(request);

            case "CAR":
                return handleCar(request);

            case "PARK":
                return handlePark(request);

            case "EXIT":
                return new ParkingResponse(0, "Goodbye!");

            default:
                return new ParkingResponse(1, "Unknown command: " + command);
        }
    }
    
    /**
     * Handles the CUSTOMER command. Validates required fields and simulates
     * registering a customer.
     *
     * @param request the parsed ParkingRequest
     * @return a ParkingResponse indicating success or error
     */
    private ParkingResponse handleCustomer(ParkingRequest request) {
        Properties props = request.getProperties();

        if (!props.containsKey("firstname") || !props.containsKey("lastname") || !props.containsKey("email")) {
            return new ParkingResponse(1, "Missing required customer fields");
        }

        String firstName = props.getProperty("firstname");
        String lastName = props.getProperty("lastname");
        String email = props.getProperty("email");

        // TODO: Register the customer in your DB or data structure
        System.out.printf("Registering customer: %s %s, email: %s%n", firstName, lastName, email);

        return new ParkingResponse(0, "Customer registered successfully");
    }
    /**
     * Handles the CAR command. Validates input and simulates registering
     * a car for an existing customer.
     *
     * @param request the parsed ParkingRequest
     * @return a ParkingResponse indicating success or error
     */
    private ParkingResponse handleCar(ParkingRequest request) {
        Properties props = request.getProperties();

        if (!props.containsKey("license") || !props.containsKey("customer")) {
            return new ParkingResponse(1, "Missing required car fields");
        }

        String license = props.getProperty("license");
        String customerId = props.getProperty("customer");

        // TODO: Link car to customer in DB or memory
        System.out.printf("Registering car: %s for customer: %s%n", license, customerId);

        return new ParkingResponse(0, "Car registered successfully");
    }
    /**
     * Handles the PARK command. Validates input and simulates parking a vehicle.
     *
     * @param request the parsed ParkingRequest
     * @return a ParkingResponse indicating success or error
     */
    private ParkingResponse handlePark(ParkingRequest request) {
        Properties props = request.getProperties();

        String license = props.getProperty("license");
        String lot = props.getProperty("lot");

        if (license == null || lot == null) {
            return new ParkingResponse(1, "Missing license or lot");
        }

        // Simulate parking logic
        System.out.printf("Car %s parked in lot %s%n", license, lot);

        return new ParkingResponse(0, "Car parked successfully");
    }
    
    
    
/**
 * The {@code ClientHandler} class is responsible for processing a single client connection.
 * It reads JSON-encoded ParkingRequest messages line-by-line, dispatches the
 * appropriate handler method based on the command, and returns a JSON-encoded
 * ParkingResponse object to the client.
 *
 * Supported commands include:
 *     {@code CUSTOMER} – Registers a customer with firstname, lastname, and email
 *     {@code CAR} – Registers a car linked to a customer ID
 *     {@code PARK} – Simulates parking a car in a specific lot
 *     {@code EXIT} – Closes the connection
 */
    // Inner class to handle client connections
    private class ClientHandler implements Runnable {

        private Socket clientSocket;

        ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }
    /**
     * Starts the thread and handles the client interaction using JSON-based protocol.
     * Reads input, parses JSON into ParkingRequest executes appropriate logic,
     * and sends back a JSON-formatted ParkingResponse.
     */
    @Override
    public void run() {
        try (
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                // Deserialize JSON string to ParkingRequest
                ParkingRequest request = ParkingRequest.fromJson(inputLine);

                // Handle request
                ParkingResponse response = handleRequest(request);

                // Send response as JSON
                out.println(response.toJson());

                if ("EXIT".equalsIgnoreCase(request.getCommand())) {
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                clientSocket.close();
            } catch (IOException ignored) {}
            System.out.println("Client disconnected");
        }
    }
}
}


