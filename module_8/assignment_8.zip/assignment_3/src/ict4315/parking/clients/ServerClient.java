package ict4315.parking.clients;

import ict4315.parking.protocol.ParkingRequest;
import ict4315.parking.protocol.ParkingResponse;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;
/**
 * The {@code ServerClient} class is a simple client-side application that connects to
 * a parking server using a socket. It sends commands using a JSON-based protocol and
 * receives structured responses.
 *
 * The client prompts the user for input (e.g., "CUSTOMER firstname=Rob"),
 * construct ParkingRequest} object with the command and parameters,
 * serializes it to JSON, and sends it to the server. It then waits for a JSON
 * response, deserializes it into a ParkingResponse, and displays the result.
 *
 * This implementation replaces the previous line-by-line command format with
 * a more robust and structured JSON protocol.
 *
 * Example input:
 * CUSTOMER firstname=Rob lastname=Smith email=rob@example.com
 *
 * Example output:
 * Status: 0, Message: Customer created successfully
 * 
 *
 * @author 
 */

public class ServerClient {
	
    /**
     * Starts the client application, connects to the server, and processes commands.
     * 
     * The client reads user input from the console, builds a ParkingRequest,
     * sends it as a JSON string, and then handles the ParkingResponse
     * received from the server.
     * 
     *
     * @param args command-line arguments (not used)
     */
	
    public static void main(String[] args) {
        String hostname = "localhost";
        int port = 8080;

        try (
            Socket socket = new Socket(hostname, port);
            OutputStream output = socket.getOutputStream();
            PrintWriter writer = new PrintWriter(output, true);
            InputStream input = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in))
        ) {
            System.out.println("Connected to the server");

            while (true) {
                System.out.print("Enter command (e.g., CUSTOMER firstname=Rob): ");
                String inputLine = consoleReader.readLine();

                if (inputLine == null || inputLine.equalsIgnoreCase("EXIT")) {
                    System.out.println("Exiting client.");
                    break;
                }

                // Parse input line into command and properties
                String[] parts = inputLine.split(" ", 2);
                String command = parts[0].toUpperCase();  // Normalize command

                Properties props = new Properties();
                if (parts.length > 1) {
                    String[] keyValues = parts[1].split(" ");
                    for (String kv : keyValues) {
                        String[] kvParts = kv.split("=", 2);
                        if (kvParts.length == 2) {
                            props.setProperty(kvParts[0], kvParts[1]);
                        }
                    }
                }

                // Build ParkingRequest and convert to JSON
                ParkingRequest request = new ParkingRequest(command, props);
                String jsonRequest = request.toJson();

                // Send JSON string to server
                writer.println(jsonRequest);

                // Read JSON response from server
                String jsonResponse = reader.readLine();

                // Deserialize into ParkingResponse
                ParkingResponse response = ParkingResponse.fromJson(jsonResponse);

                // Print status and message clearly
                System.out.printf("Status: %d, Message: %s%n", response.getStatusCode(), response.getMessage());
            }

            System.out.println("Disconnected.");

        } catch (UnknownHostException e) {
            System.out.println("Server not found: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("I/O error: " + e.getMessage());
        }
    }
}
