package ict4315.parking.observer.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ict4315.parking.charges.strategy.FlatDailyRateStrategy;
import ict4315.parking.observer.ParkingEvent;
import ict4315_assignment_1.Address;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;

class ParkingEventTest {

	private ParkingPermit parkingPermit;
    private ParkingLot parkingLot;
    private LocalDateTime timestamp;
    private Address address;
    private boolean isEntry;

    @BeforeEach
    public void setUp() {
        // Set up test data (you may need to create or mock ParkingPermit and ParkingLot)
    	address = new Address("345 Basoon St.", "Lot 2", "Chicago", "IL", "60021");
        parkingPermit = new ParkingPermit("ABC123", null, timestamp);
        parkingLot = new ParkingLot("P001", "Lot A", address, new FlatDailyRateStrategy(), 0, 100);
        timestamp = LocalDateTime.now();
        isEntry = true;
    }

    /**
     * Tests the constructor of ParkingEvent to ensure all fields are initialized correctly.
     */
    @Test
    public void testConstructor() {
        ParkingEvent event = new ParkingEvent(parkingPermit, parkingLot, timestamp, isEntry);
        
        assertEquals(parkingPermit, event.getPermit());
        assertEquals(parkingLot, event.getLot());
        assertEquals(timestamp, event.getTimeStamp());
        assertTrue(event.isEntry());
    }
    /**
     * Tests that two ParkingEvent instances with different timestamps are not equal.
     */
    @Test
    public void testNotEqual() {
        ParkingEvent event1 = new ParkingEvent(parkingPermit, parkingLot, timestamp, isEntry);
        ParkingEvent event2 = new ParkingEvent(parkingPermit, parkingLot, timestamp.plusMinutes(1), isEntry);

        assertNotEquals(event1, event2, "Events should not be equal when their timestamps differ.");
    }
}
