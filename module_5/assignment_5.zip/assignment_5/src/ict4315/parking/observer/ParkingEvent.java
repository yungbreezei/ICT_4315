package ict4315.parking.observer;

import java.time.LocalDateTime;

import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;

public class ParkingEvent {
	
	private final ParkingPermit permit;
	private final ParkingLot lot;
	private final LocalDateTime timeStamp;
	private final boolean isEntry;
	
	public ParkingEvent(ParkingPermit permit, ParkingLot lot, 
			LocalDateTime timeStamp, boolean isEntry) {
		
		this.permit = permit;
		this.lot = lot;
		this.timeStamp = timeStamp;
		this.isEntry = isEntry;
	}
	
	/*
	 * Getters
	 */
	public ParkingPermit getPermit() {
		return permit;
	}
	public ParkingLot getLot() {
		return lot;
	}
	public LocalDateTime getTimeStamp() {
		return timeStamp;
	}
	public boolean isEntry() {
		return isEntry;
	}
}
