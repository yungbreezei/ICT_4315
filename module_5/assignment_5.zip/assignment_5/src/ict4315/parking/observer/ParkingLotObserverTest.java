package ict4315.parking.observer;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ict4315.parking.charges.factory.DefaultParkingChargeStrategyFactory;
import ict4315.parking.charges.factory.ParkingChargeStrategyFactory;
import ict4315.parking.charges.strategy.ParkingChargeStrategy;
import ict4315_assignment_1.Address;
import ict4315_assignment_1.Car;
import ict4315_assignment_1.CarType;
import ict4315_assignment_1.Customer;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;
import ict4315_assignment_1.ParkingTransaction;
import ict4315_assignment_1.PermitManager;
import ict4315_assignment_1.TransactionManager;

class ParkingLotObserverTest {

    private TransactionManager transactionManager;
    private ParkingObserver parkingObserver;
    private ParkingLot lot;
    private ParkingPermit permit;
    private Car car;
    private Customer customer;

    @BeforeEach
    void setUp() {
        Address address = new Address("123 Main", "Apt 3", "Denver", "CO", "80000");

        // Create factory and transaction manager
        ParkingChargeStrategyFactory strategyFactory = new DefaultParkingChargeStrategyFactory();
        transactionManager = new TransactionManager(strategyFactory);

        // Set up ParkingLot
        lot = new ParkingLot("2345634", "Lot A", address, null, 7, 100); // Ensure lot is initialized before usage
        ParkingChargeStrategy chargeStrategy = strategyFactory.getStrategyFor(lot);
        lot.setChargeStrategy(chargeStrategy); // Assuming setter method exists

        customer = new Customer("14273", "John", "Doe", "555-555-5555", address);
        car = new Car(CarType.SUV, "XYZ-1235", customer);

        PermitManager permitManager = new PermitManager();
        permit = permitManager.register(car);

        // Setup observer with a single-lot list
        List<ParkingLot> lots = new ArrayList<>();
        lots.add(lot);
        parkingObserver = new ParkingObserver(transactionManager, lots);
        lot.addObserver(parkingObserver);
    }
    
    @Test
    void testParkingObserverCreatesTransaction() {
        // Simulate entry and exit
        lot.enter(permit);

        try {
            Thread.sleep(2000); // Simulate time gap between entry and exit
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        lot.exit(permit);

        // Verify a transaction was created
        List<ParkingTransaction> transactions = transactionManager.getTransactions();
        assertEquals(2, transactions.size(), "Transaction should have been created.");

        ParkingTransaction transaction = transactions.get(0);
        assertEquals(permit, transaction.getPermit(), "Permit should match.");
        assertEquals(lot, transaction.getParkingLot(), "Lot should match.");
        assertNotNull(transaction.getEntryTime(), "Entry time should not be null.");
        assertNotNull(transaction.getExitTime(), "Exit time should not be null.");
        assertTrue(transaction.getExitTime().isAfter(transaction.getEntryTime()), 
                   "Exit should be after entry.");
    }
}
