package ict4315.parking.observer;

public interface ParkingAction {

		void update(ParkingEvent event);
	}
