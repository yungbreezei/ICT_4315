package ict4315.parking.observer;

import java.util.List;

import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.TransactionManager;

public class ParkingObserver implements ParkingAction{

	private final TransactionManager transactionManager;
	
	public ParkingObserver(TransactionManager transactionManager, List<ParkingLot> lots) {
		
	    this.transactionManager = transactionManager;

	    // Ensure ParkingObserver registers with all lots
	    for (ParkingLot lot : lots) {
	        lot.addObserver(this); // Register the current instance (this) as the observer
	    }
	}

	@Override
	public void update(ParkingEvent event) {
		transactionManager.park(event);		
	}
}
