package ict4315.parking.observer;

import java.util.List;

import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.TransactionManager;

public class ParkingObserver implements ParkingAction{

	private final TransactionManager transactionManager;
	
	public ParkingObserver (TransactionManager transactionManager, 
			List<ParkingLot> lots) {
		this.transactionManager = transactionManager;
		for(ParkingLot lot : lots){
			lot.addObserver(null);
		}
	}	

	@Override
	public void update(ParkingEvent event) {
		transactionManager.park(event);		
	}
}
