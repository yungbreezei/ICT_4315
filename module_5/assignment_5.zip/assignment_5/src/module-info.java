/**
 * 
 */
/**
 * 
 */
module assignment_1 {
	requires org.junit.jupiter.api;
	requires junit;
	requires java.sql;
}