/* Bria Wright
 * 
 * ICT 4315
 * Week 1 Assignment: Translating UML into Code
 * April 6, 2025
 */

package ict4315_assignment_1;

import java.util.ArrayList;
import java.util.HashMap;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID; // Needed to generate unique transaction IDs

import ict4315.parking.charges.factory.ParkingChargeStrategyFactory;
import ict4315.parking.charges.strategy.ParkingChargeStrategy;
import ict4315.parking.observer.ParkingEvent;


/**
 * This is the class that manages all the parking transactions.
 */
public class TransactionManager {
	
    private List<ParkingTransaction> transactions;
    private ParkingChargeStrategyFactory strategyFactory;
    
    private Map<ParkingPermit, LocalDateTime> activeEntries;


	    // Constructor to initialize the transaction manager
	    public TransactionManager(ParkingChargeStrategyFactory strategyFactory) {
	    	
	        this.transactions = new ArrayList<>();
	        this.strategyFactory = strategyFactory;
	        this.activeEntries = new HashMap<>();
	    }
	    
	    /*
	     * Getters
	     */
	    public List<ParkingTransaction> getTransactions() {
	        return new ArrayList<>(transactions); // Return a copy for encapsulation
	    }

	    
	    /*
	     * Setters
	     */
	    public void setTransactions(List<ParkingTransaction> transactions) {
	    	this.transactions = transactions;
	    }
	    
	    /*
	     * Main method called by ParkingObserver when a ParkingEvent is triggered
	     */
		public void park(ParkingEvent event) {
	    	
	        // Check for null values before proceeding
	        if (event == null || event.getPermit() == null || event.getLot() == null) {
	            throw new IllegalArgumentException("ParkingEvent or missing data.");
	        }
	        
	        ParkingPermit permit = event.getPermit();
	        ParkingLot lot = event.getLot();
	        LocalDateTime timestamp = event.getTimeStamp();

	        if (event.isEntry()) {
	            // Record entry time
	            activeEntries.put(permit, timestamp);
	            
	            System.out.println("Entry recorded for permit: " + permit.getId() 
	            + " at " + timestamp);
	        } else {
	            // Process exit time, Retrieve and remove the matching entry time
	            LocalDateTime entryTime = activeEntries.remove(permit); // remove to clear it
	            
	            if (entryTime == null) {
	                throw new IllegalStateException("No entry recorded for permit: " + permit.getId());
	            }
	            System.out.println("Exit recorded for permit: " + permit.getId() + " with entry at " + entryTime);
	        

	            if (!activeEntries.containsKey(permit)) {
	                activeEntries.put(permit, timestamp);  // Only record if it's not already recorded
	                System.out.println("Entry recorded for permit: " + permit.getId() + 
	                		" at " + timestamp);
	            } else {
	                System.out.println("Duplicate entry ignored for permit: " + permit.getId());
	            }

	            // Calculate the charge
	            ParkingChargeStrategy strategy = strategyFactory.getStrategyFor(lot);
	            if (strategy == null) {
	                throw new IllegalArgumentException("No charge strategy found for lot: " + 
	                		lot.getName());
	            }

	            Money baseRate = lot.getBaseRate();
	            Money chargedAmount = strategy.calculateCharge(permit, entryTime, 
	            		timestamp, baseRate);

	            // Create and store the transaction
	            ParkingTransaction transaction = new ParkingTransaction(
	                UUID.randomUUID().toString(),
	                entryTime,
	                timestamp,
	                permit,
	                lot,
	                chargedAmount
	            );

	            transactions.add(transaction);
	        }
	    }
	    
	    /*
	     * Returns total charges for a specific parking permit
	     */
	    public Money getParkingCharges(ParkingPermit permit) {
	        double total = transactions.stream()
	                .filter(t -> t.getPermit().equals(permit))
	                .mapToDouble(t -> t.getChargedAmount().getAmount())
	                .sum();
	        
	        return new Money(total, "USD");
	    }
	    
	    /*
	     * Returns total charges for all transactions of a given customer
	     */
	    public Money getParkingCharges(Customer customer) {
	        if (customer == null) {
	            throw new IllegalArgumentException("Customer cannot be null.");
	        }

	        double total = transactions.stream()
	                .filter(t -> t.getPermit().getCar().getOwner().equals(customer))
	                .mapToDouble(t -> t.getChargedAmount().getAmount())
	                .sum();
	        
	        return new Money(total, "USD");
	    }
	}
