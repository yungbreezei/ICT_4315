package ict4315.parking.observer.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ParkingEventTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
