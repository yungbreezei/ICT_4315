package ict4315.charges.decorator;

import java.time.LocalDateTime;

import ict4315_assignment_1.CarType;
import ict4315_assignment_1.Money;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;

/**
 * Decorator that applies a discount to the parking charge if the car is of type {COMPACT}.
 *
 * This class extends ParkingChargeCalculatorDecorator and modifies the behavior of
 * the getParkingCharge method by applying a 20% discount for compact cars. For other car
 * types, the charge is unchanged.
 *
 * It wraps another ParkingChargeCalculator instance and delegates the base charge
 * calculation to it, applying additional logic afterward.
 *
 */

public class CompactCarDiscountDecorator extends ParkingChargeCalculatorDecorator  {

    /**
     * Constructs a new {@code CompactCarDiscountDecorator} with the given base component.
     *
     * @param component the base {@code ParkingChargeCalculator} to decorate
     */
	
	public CompactCarDiscountDecorator (ParkingChargeCalculator component) {
		super(component);
	}

    /**
     * Calculates the parking charge with a 20% discount applied if the car is a {COMPACT} type.
     * Delegates to the wrapped component to get the base charge first.
     *
     * @param startTime the start time of the parking session
     * @param endTime the end time of the parking session
     * @param lot the parking lot being used
     * @param permit the parking permit associated with the vehicle
     * @return the adjusted Money charge with discount if applicable
     */
	
	@Override
	public Money getParkingCharge(LocalDateTime startTime, LocalDateTime endTime, ParkingLot lot,
			ParkingPermit permit) {
		
	    Money baseCharge = component.getParkingCharge(startTime, endTime, lot, permit);
	    
        if (permit.getCar() != null && permit.getCar().getType() == CarType.COMPACT) {
        	return baseCharge.times(0.80); // Apply 20% discount
        }
	    return baseCharge;
	}
	
}
