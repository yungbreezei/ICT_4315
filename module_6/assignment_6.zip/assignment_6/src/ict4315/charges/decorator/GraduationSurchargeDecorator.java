package ict4315.charges.decorator;

import java.time.LocalDateTime;
import java.time.Month;

import ict4315_assignment_1.Car;
import ict4315_assignment_1.CarType;
import ict4315_assignment_1.Money;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;

public class GraduationSurchargeDecorator extends ParkingChargeCalculatorDecorator{

	// The surcharge applied on graduation day
	private static final Money GRADUATION_SURCHARGE = new Money(2.00, "USD");
	
	public GraduationSurchargeDecorator(ParkingChargeCalculator component) {
		super(component);
	}

	@Override
	public Money getParkingCharge(LocalDateTime startTime, LocalDateTime endTime, ParkingLot lot,
			ParkingPermit permit) {
		
		Money baseCharge = component.getParkingCharge(startTime, endTime, lot, permit);
		Car car = permit.getCar();
		
		if (isGraduationDay(startTime) && 
			    (car.getType() == CarType.COMPACT || car.getType() == CarType.SUV)) {
			
			    baseCharge = baseCharge.add(GRADUATION_SURCHARGE);
			}
		return baseCharge;
	}

    private boolean isGraduationDay(LocalDateTime date) {
    	// check the date & return if the date is May 10th
        return date.getMonth() == Month.MAY && date.getDayOfMonth() == 10 && 
        		date.getYear() == 2025;
    }

}
