package ict4315.charges.decorator;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.Month;

import ict4315_assignment_1.Money;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;

public class WeekendFreeDecorator extends ParkingChargeCalculatorDecorator{
	
	public WeekendFreeDecorator(ParkingChargeCalculator component) {
		super(component);
	}

	@Override
	public Money getParkingCharge(LocalDateTime startTime, LocalDateTime endTime, ParkingLot lot,
			ParkingPermit permit) {
		
		DayOfWeek day = startTime.getDayOfWeek();
		Money baseCharge = component.getParkingCharge(startTime, endTime, lot, permit);
		
        if ((day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) && 
        !(isGraduationDay(startTime))) {
        	
            return new Money(0.00, "USD");
        }
        
		return baseCharge;
	}

	private boolean isGraduationDay(LocalDateTime startTime) {
		
        return startTime.getMonth() == Month.MAY && startTime.getDayOfMonth() == 10 && 
        		startTime.getYear() == 2025;
    }

}
