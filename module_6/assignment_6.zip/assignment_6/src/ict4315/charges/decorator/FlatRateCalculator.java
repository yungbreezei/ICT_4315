package ict4315.charges.decorator;

import java.time.Duration;
import java.time.LocalDateTime;

import ict4315_assignment_1.Money;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;

/**
 * FlatRateCalculator calculates parking charges based on a fixed hourly rate,
 * regardless of location or car type.
 * 
 * This class extendsParkingChargeCalculator and implements
 * a simple charge calculation by multiplying the number of hours parked
 * by a flat hourly rate. The minimum billable time is 1 hour.
 * 
 */

public class FlatRateCalculator extends ParkingChargeCalculator{

	private final double hourlyRate;
	private final String currency;
	
    /**
     * Constructs a FlatRateCalculator with the given hourly rate and currency.
     *
     * @param hourlyRate the flat rate charged per hour of parking
     * @param currency the currency in which the charge is expressed ("USD")
     */
	
	public FlatRateCalculator(double hourlyRate, String currency) {
		this.hourlyRate = hourlyRate;
		this.currency = currency;
	}
	
    /**
     * Calculates the parking charge based on the duration between start and end time.
     * The minimum charge is for one hour.
     *
     * @param startTime the time the parking session started
     * @param endTime the time the parking session ended
     * @param lot the parking lot where the session occurred
     * @param permit the permit associated with the parked car
     * @return a Money object representing the total parking charge
     */
	
	@Override
	public Money getParkingCharge(LocalDateTime startTime, LocalDateTime endTime, ParkingLot lot,
			ParkingPermit permit) {
		
		long hours = Math.max(1, Duration.between(startTime, endTime).toHours());
        return new Money(hours * hourlyRate, currency);
	}

}
