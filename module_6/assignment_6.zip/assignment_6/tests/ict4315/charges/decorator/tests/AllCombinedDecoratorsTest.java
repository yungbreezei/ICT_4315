package ict4315.charges.decorator.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ict4315_assignment_1.Address;
import ict4315_assignment_1.Car;
import ict4315_assignment_1.CarType;
import ict4315_assignment_1.Customer;
import ict4315_assignment_1.Money;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;
import ict4315.charges.decorator.ParkingChargeCalculator;
import ict4315.charges.decorator.WeekendFreeDecorator;
import ict4315.charges.decorator.FlatRateCalculator;
import ict4315.charges.decorator.GraduationSurchargeDecorator;
import ict4315.charges.decorator.CompactCarDiscountDecorator;

class AllCombinedDecoratorsTest {
	
    private ParkingChargeCalculator calculator;
    private ParkingLot lot;
    private ParkingPermit permit;

    @BeforeEach
    void setUp() {
        // Setup common data for each test
    	Address address = new Address("123 Main St", null, "GradTown", "CO", "80000");
        lot = new ParkingLot("Lot X", "Standard Lot", address, null, 10.0, 50);
        
        
        Customer customer = new Customer("C001", "Alice", "Smith", "123-456-7890", address);
        // Create a default permit for a compact car
        Car compactCar = new Car(CarType.COMPACT, "ABC-1234", customer);
        permit = new ParkingPermit("PERM-001", compactCar, LocalDateTime.of(2028, 1, 1, 0, 0));

        // Default calculator setup (FlatRateCalculator as base)
        calculator = new FlatRateCalculator(10.0, "USD");
    }
	@Test
    void CompactCarGraduationDayWithAllDecorators() {

        // May 10, 2025 (Graduation Day), 2 hours
        LocalDateTime start = LocalDateTime.of(2025, 5, 10, 10, 0);
        LocalDateTime end = LocalDateTime.of(2025, 5, 10, 12, 0);

        ParkingChargeCalculator calculator = new FlatRateCalculator(5.0, "USD");
        calculator = new CompactCarDiscountDecorator(calculator);
        calculator = new WeekendFreeDecorator(calculator);
        calculator = new GraduationSurchargeDecorator(calculator);

        Money charge = calculator.getParkingCharge(start, end, lot, permit);

        // $10 * 0.8 = $8 + $2 surcharge = $10
        assertEquals(10.0, charge.getAmount(), 0.01);
    }

    @Test
    void CompactCarOnWeekendGetsFreeParking() {

        // Sunday, May 11, 2025
        LocalDateTime start = LocalDateTime.of(2025, 5, 11, 10, 0);
        LocalDateTime end = LocalDateTime.of(2025, 5, 11, 12, 0);

        ParkingChargeCalculator calculator = new FlatRateCalculator(5.0, "USD");
        calculator = new CompactCarDiscountDecorator(calculator);
        calculator = new WeekendFreeDecorator(calculator);
        calculator = new GraduationSurchargeDecorator(calculator);

        Money charge = calculator.getParkingCharge(start, end, lot, permit);

        // Weekend = free regardless of other decorators
        assertEquals(0.0, charge.getAmount(), 0.01);
    }
    
    @Test
    void SuvOnWeekendGetsFreeParking() {

        // Sunday, May 11, 2025
        LocalDateTime start = LocalDateTime.of(2025, 5, 11, 10, 0);
        LocalDateTime end = LocalDateTime.of(2025, 5, 11, 12, 0);

        ParkingChargeCalculator calculator = new FlatRateCalculator(5.0, "USD");
        calculator = new CompactCarDiscountDecorator(calculator);
        calculator = new WeekendFreeDecorator(calculator);
        calculator = new GraduationSurchargeDecorator(calculator);

        Money charge = calculator.getParkingCharge(start, end, lot, permit);

        // Weekend = free regardless of other decorators
        assertEquals(0.0, charge.getAmount(), 0.01);
    }

    @Test
    void SUVOnGraduationDayWithAllDecorators() {
        Address address = new Address("123 Main St", null, "GradTown", "CO", "80000");
        Customer customer = new Customer("C003", "Carol", "White", "123-456-7890", address);
        Car suv = new Car(CarType.SUV, "SUV-5555", customer);
        ParkingPermit permit = new ParkingPermit("PERM-003", suv, LocalDateTime.of(2024, 1, 1, 0, 0));
        ParkingLot lot = new ParkingLot("Lot G", "Grad Lot", address, null, 5.0, 100);

        LocalDateTime start = LocalDateTime.of(2025, 5, 10, 8, 0);
        LocalDateTime end = LocalDateTime.of(2025, 5, 10, 10, 0); // 2 hours

        ParkingChargeCalculator calculator = new FlatRateCalculator(5.0, "USD");
        calculator = new CompactCarDiscountDecorator(calculator);
        calculator = new GraduationSurchargeDecorator(calculator);
        calculator = new WeekendFreeDecorator(calculator);


        Money charge = calculator.getParkingCharge(start, end, lot, permit);

        // No discount (SUV), but surcharge applied: $10 + $2 = $12 
        assertEquals(12.0, charge.getAmount(), 0.01);
    }

}
