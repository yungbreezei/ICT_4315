package ict4315.charges.decorator.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ict4315.charges.decorator.CompactCarDiscountDecorator;
import ict4315.charges.decorator.FlatRateCalculator;
import ict4315.charges.decorator.GraduationSurchargeDecorator;
import ict4315.charges.decorator.ParkingChargeCalculator;
import ict4315.charges.decorator.WeekendFreeDecorator;
import ict4315_assignment_1.Address;
import ict4315_assignment_1.Car;
import ict4315_assignment_1.CarType;
import ict4315_assignment_1.Customer;
import ict4315_assignment_1.Money;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;

class FlatRateCalculatorTest {

    private ParkingChargeCalculator calculator;
    private ParkingLot lot;
    private ParkingPermit permit;

    @BeforeEach
    void setUp() {
        // Setup common data for each test
    	Address address = new Address("123 Main St", null, "GradTown", "CO", "80000");
        lot = new ParkingLot("Lot X", "Standard Lot", address, null, 10.0, 50);
        
        
        Customer customer = new Customer("C001", "Alice", "Smith", "123-456-7890", address);
        // Create a default permit for a compact car
        Car compactCar = new Car(CarType.COMPACT, "ABC-1234", customer);
        permit = new ParkingPermit("PERM-001", compactCar, LocalDateTime.of(2028, 1, 1, 0, 0));

        // Default calculator setup (FlatRateCalculator as base)
        calculator = new FlatRateCalculator(10.0, "USD");
    }
	
	@Test
    void FlatRateOnly() {
        Money charge = calculator.getParkingCharge(LocalDateTime.of(2025, 5, 1, 10, 0),
                LocalDateTime.of(2025, 5, 1, 12, 0),
                lot,
                permit);
        assertEquals(new Money(20.0, "USD"), charge);
	}
	
	@Test
	void FlatRateAndCompactCarDiscount() {
	    Customer testCustomer = new Customer("C1", "Test", "User", "800-526-5421", null);
	    Car compactCar = new Car(CarType.COMPACT, "ABC-1234", testCustomer);
	    ParkingPermit compactPermit = new ParkingPermit("P1", compactCar, LocalDateTime.now().plusDays(30));

	    calculator = new CompactCarDiscountDecorator(
	                    new FlatRateCalculator(10.0, "USD"));

	    Money charge = calculator.getParkingCharge(
	        LocalDateTime.of(2025, 5, 9, 10, 0),
	        LocalDateTime.of(2025, 5, 9, 12, 0),
	        lot,
	        compactPermit
	    );

	    assertEquals(new Money(16.0, "USD"), charge);
	}
	
	@Test
    void FlatRateGraduationSurcharge() {
        calculator = new GraduationSurchargeDecorator(new FlatRateCalculator(10, "USD"));
        Money charge = calculator.getParkingCharge(LocalDateTime.of(2025, 5, 10, 10, 0),
                                                   LocalDateTime.of(2025, 5, 10, 12, 0),
                                                   lot,
                                                   permit);
        assertEquals(new Money(22.0, "USD"), charge); // $10 + $2 surcharge
    }

	@Test
    void FlatRateWeekendFree() {
        calculator = new WeekendFreeDecorator(new FlatRateCalculator(10.0, "USD"));
        Money charge = calculator.getParkingCharge(LocalDateTime.of(2025, 5, 11, 10, 0),  // Sunday
                                                   LocalDateTime.of(2025, 5, 11, 12, 0),
                                                   lot,
                                                   permit);
        assertEquals(new Money(0.0, "USD"), charge);
    }
	
	@Test
    void FlatRateCompactCarGraduationDay() {
        calculator = new GraduationSurchargeDecorator(
        		new CompactCarDiscountDecorator(
                new FlatRateCalculator(10, "USD")));
        Money charge = calculator.getParkingCharge(LocalDateTime.of(2025, 5, 10, 10, 0),
                                           LocalDateTime.of(2025, 5, 10, 12, 0),
                                           lot,
                                           permit);
		assertEquals(new Money(18.0, "USD"), charge);
	}
	
	@Test
    void AllThreeDecoratorsOnGraduationSaturday() {
        calculator = new CompactCarDiscountDecorator(
                new GraduationSurchargeDecorator(
                new WeekendFreeDecorator(
                new FlatRateCalculator(10, "USD"))));
        
    	Money charge = calculator.getParkingCharge(LocalDateTime.of(2025, 5, 10, 10, 0),  // Graduation & Saturday
                                           LocalDateTime.of(2025, 5, 10, 12, 0),
                                           lot,
                                           permit);
    	assertEquals(new Money(17.60, "USD"), charge);
	}
	
    @Test
    void AllThreeDecoratorsOnWeekday() {
        calculator = new CompactCarDiscountDecorator(
                        new GraduationSurchargeDecorator(
                            new WeekendFreeDecorator(
                                new FlatRateCalculator(10, "USD"))));
        Money charge = calculator.getParkingCharge(LocalDateTime.of(2025, 5, 9, 10, 0),  // Not graduation
                                                   LocalDateTime.of(2025, 5, 9, 12, 0),
                                                   lot,
                                                   permit);
        assertEquals(new Money(16.0, "USD"), charge); // Only discount applies
    }
	
}
