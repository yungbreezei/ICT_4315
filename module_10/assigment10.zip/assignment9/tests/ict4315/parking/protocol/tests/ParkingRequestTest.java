package ict4315.parking.protocol.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import ict4315.parking.protocol.ParkingRequest;

import java.util.Properties;

/**
 * Unit tests for the ParkingRequest} class.
 * These tests verify the correctness of constructors, property handling,
 * JSON serialization, and deserialization.
 */
public class ParkingRequestTest {

    /**
     * Tests the ParkingRequest constructor and {@code toString()} method.
     * Ensures that command and property values are correctly stored and represented.
     */
    @Test
    public void testConstructorAndToString() {
        Properties props = new Properties();
        props.setProperty("license", "ABC123");
        props.setProperty("lot", "MainLot");

        ParkingRequest request = new ParkingRequest("PARK");

        assertEquals("PARK", request.getCommand());
        assertEquals("ABC123", request.getProperties().get("license"));
        assertTrue(request.toString().contains("PARK"));
        assertTrue(request.toString().contains("license=ABC123"));
    }

    /**
     * Tests JSON serialization using ParkingRequest#toJson() and
     * deserialization using ParkingRequestfromJson(String).
     * Ensures the original object and the deserialized object have equivalent data.
     */
    @Test
    public void testToJsonAndFromJson() {
        Properties props = new Properties();
        props.setProperty("firstname", "Jane");
        props.setProperty("lastname", "Doe");

        ParkingRequest originalRequest = new ParkingRequest("CUSTOMER");
        String json = originalRequest.toJson();

        assertNotNull(json);
        assertTrue(json.contains("CUSTOMER"));

        ParkingRequest deserialized = ParkingRequest.fromJson(json);
        assertEquals(originalRequest.getCommand(), deserialized.getCommand());
        assertEquals(originalRequest.getProperties().get("firstname"),
                     deserialized.getProperties().get("firstname"));
        assertEquals(originalRequest.getProperties().get("lastname"),
                     deserialized.getProperties().get("lastname"));
    }
}
