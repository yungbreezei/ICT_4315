package assignment_1;

import com.google.inject.Guice;
import com.google.inject.Injector;
import ict4315_assignment_1.ParkingService;
import ict4315_assignment_1.*;
import ict4315.guice.ParkingModule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.google.inject.AbstractModule;
import com.google.inject.Guice;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class ParkingServiceTest {

    private ParkingService parkingService;
    private Injector injector;
    

    @BeforeEach
    public void setUp() {
        // Create injector with ParkingModule (ensure it binds all required classes)
        injector = Guice.createInjector(new ParkingModule());
        parkingService = injector.getInstance(ParkingService.class);
    }

    /**
     * Test case to ensure a valid command is executed properly.
     */
    @Test
    public void testPerformCommand_ValidCommand() {
        String[] args = {
                "id=CUST001",
                "firstName=John",
                "lastName=Doe",
                "phoneNumber=870-555-1234",
                "address=123 Main St, apt 3, Springfield, IL, 62704"
        };

        String result = parkingService.performCommand("RegisterCustomer", args);
        assertFalse(result.equals("Customer registered successfully") || result.equals("Customer already exists"));
    }
    
    @Test
    void testGuiceIntegrationCreatesParkingService() {
        Injector injector = Guice.createInjector(new ParkingModule());
        ParkingService service = injector.getInstance(ParkingService.class);

        assertNotNull(service);
    }
    
    /**
     * Test case to check for invalid command execution.
     */
    @Test
    public void testPerformCommand_InvalidCommand() {
        String[] args = {
                "id=CUST002",
                "firstName=Jane",
                "lastName=Smith",
                "phoneNumber=870-555-1234",
                "address=456 Oak St, lot 3, Denver, CO, 80014"
        };

        String result = parkingService.performCommand("InvalidCommand", args);
        assertEquals("Invalid Command", result);
    }
    
    @Test
    public void testParkingOfficeDirectly() {
        ParkingOffice office = injector.getInstance(ParkingOffice.class);
        Customer customer = new Customer(
            "CUST001", "John", "Doe", "123-456-7890", 
            new Address("123 St", "", "City", "ST", "12345")
        );
        assertNotNull(customer);
    }
    
    @Test
    public void testCarTypeSerialization() throws Exception {
        CarType original = CarType.SUV;
        
        // Serialize
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        new ObjectOutputStream(bos).writeObject(original);
        
        // Deserialize
        ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
        CarType deserialized = (CarType) new ObjectInputStream(bis).readObject();
        
        assertSame(original, deserialized);  // Enums guarantee instance equality
        assertEquals("SUV", deserialized.name());
    }
}
