package ict4315.guice;

import com.google.inject.AbstractModule;
import com.google.inject.Provides;
import com.google.inject.Singleton;

import ict4315.parking.charges.factory.DefaultParkingChargeStrategyFactory;
import ict4315.parking.charges.factory.ParkingChargeStrategyFactory;
import ict4315_assignment_1.*;


/**
 * Guice module that configures the dependency injection bindings for the Parking System application.
 * 
 * This module defines how the application's components should be instantiated and wired together.
 * It provides bindings for core services, commands, and their dependencies.
 * 
 */
public class ParkingModule extends AbstractModule {
    @Override
    protected void configure() {
        // Bind command implementations
        bind(RegisterCustomerCommand.class);
        bind(RegisterCarCommand.class);
        
        // Bind core services
        bind(ParkingService.class);
        
        // Bind strategy factory to its default implementation
        bind(ParkingChargeStrategyFactory.class).to(DefaultParkingChargeStrategyFactory.class);

    }
    /**
     * Provides a default Address instance.
     * 
     * This serves as the default address used throughout the application when
     * no specific address is provided.
     *      * 
     * @return A new Address instance with default values
     */
    @Provides
    public Address provideAddress() {
        return new Address("123 Main St", "Suite 100", "Denver", "CO", "80210");
    }

    /**
     * Provides a singleton instance of ParkingOffice.
     *
     * The ParkingOffice is configured with a default name, address, and charge strategy factory.
     * It is marked as a singleton to ensure there's only one instance in the application.
     *       
     * @param address The default address to use (injected)
     * @param factory The parking charge strategy factory (injected)
     * @return A singleton ParkingOffice instance
     */
    @Provides
    @Singleton
    public ParkingOffice provideParkingOffice(Address address, ParkingChargeStrategyFactory factory) {
        return new ParkingOffice("Main Office", address, factory);
    }

}
