package ict4315.parking.observer;

/**
 * The ParkingAction interface defines a callback method
 * for receiving parking-related events, such as vehicle entries and exits.
 * 
 * Classes implementing this interface act as observers and are notified 
 * when a ParkingEvent occurs.
 * 
 */

public interface ParkingAction {
	
    /**
     * Called when a parking event occurs in a monitored parking lot.
     *
     * @param event the parking event containing data such as permit, lot, timestamp,
     *              and whether the event is an entry or exit
     */
	
		void update(ParkingEvent event);
	}
