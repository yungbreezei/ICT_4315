package ict4315.parking.common;

import java.util.Map;

public class CommandMessage {
    private String command;
    private Map<String, String> parameters;

    // Required by Gson
    public CommandMessage() {}

    public CommandMessage(String command, Map<String, String> parameters) {
        this.command = command;
        this.parameters = parameters;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public Map<String, String> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, String> parameters) {
        this.parameters = parameters;
    }
}
