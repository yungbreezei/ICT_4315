package ict4315.parking.charges.factory;

import ict4315.parking.charges.strategy.ParkingChargeStrategy;
import ict4315_assignment_1.ParkingLot;

public interface ParkingChargeStrategyFactory {
    /**
     * Returns the appropriate ParkingChargeStrategy for the given parking lot.
     *
     * @param lot the ParkingLot for which a charging strategy is needed
     * @return the applicable ParkingChargeStrategy implementation
     */
	
	ParkingChargeStrategy getStrategyFor(ParkingLot lot);
}
