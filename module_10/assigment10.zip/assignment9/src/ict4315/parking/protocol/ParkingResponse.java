package ict4315.parking.protocol;

import com.google.gson.Gson;

/**
 * Represents a response message returned by the parking server.
 * The response contains a status code and a message to indicate
 * the result of a client's request.
 *   Status code 0 typically means success.
 *   Status code 1 typically indicates an error.
 */
public class ParkingResponse {
    private int statusCode;    // e.g., 0 = success, 1 = error
    private String message;

    /**
     * Constructs a {@code ParkingResponse} with the given status code and message.
     *
     * @param statusCode the status code indicating success or failure
     * @param message a human-readable message describing the result
     */
    public ParkingResponse(int statusCode, String message) {
        this.statusCode = statusCode;
        this.message = message;
    }

    /**
     * No-argument constructor required for Gson deserialization.
     */
    public ParkingResponse() {}

    /**
     * Returns the status code of the response.
     *
     * @return the status code (e.g., 0 for success, 1 for error)
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * Returns the message included in the response.
     *
     * @return the response message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the status code of the response.
     *
     * @param statusCode the new status code
     */
    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Sets the message of the response.
     *
     * @param message the new message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Returns a string representation of the ParkingResponse.
     *
     * @return a string describing the response
     */
    @Override
    public String toString() {
        return "ParkingResponse{" +
                "statusCode=" + statusCode +
                ", message='" + message + '\'' +
                '}';
    }

    /**
     * Serializes this response into its JSON representation.
     *
     * @return the JSON string representing this response
     */
    public String toJson() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }

    /**
     * Deserializes a JSON string into a ParkingResponse} object.
     *
     * @param json the JSON string to deserialize
     * @return the corresponding ParkingResponse object
     */
    public static ParkingResponse fromJson(String json) {
        Gson gson = new Gson();
        return gson.fromJson(json, ParkingResponse.class);
    }
}