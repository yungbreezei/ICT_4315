package ict4315.parking.protocol;

import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
/**
 * Represents a request sent to the parking server.
 * Encapsulates a command (e.g., "PARK", "CUSTOMER") and an optional set of properties
 * containing parameters relevant to the command.
 * This class supports JSON serialization and deserialization using Gson.
 */
public class ParkingRequest {
    private String command;  // e.g. "PARK", "CUSTOMER"
    private Map<String, String> properties;

    // No-args constructor for Gson
    public ParkingRequest() {
        this.properties = new HashMap<>();
    }    
    /**
     * Constructs a ParkingRequest with the specified command and an empty properties map.
     *
     * @param command the command to be executed
     */
    public ParkingRequest(String command) {
        this.command = command;
        this.properties = new HashMap<>();
    }
    
    /**
     * Constructs a ParkingRequest with the specified command and properties.
     *
     * @param command the command to be executed
     * @param properties the key-value parameters for the command
     */
    public ParkingRequest(String command, Map<String, String> properties) {
        this.command = command;
        this.properties = properties != null ? properties : new HashMap<>();
    }

    /**
     * Returns the command string associated with this request.
     *
     * @return the command string
     */
    public String getCommand() {
        return command;
    }

    /**
     * Returns the properties associated with this request.
     *
     * @return the properties object
     */
    public Map<String, String> getProperties() {
        return properties;
    }

    /**
     * Sets the command string for this request.
     *
     * @param command the command to be set
     */
    public void setCommand(String command) {
        this.command = command;
    }

    /**
     * Sets the properties for this request.
     *
     * @param properties the properties to be set
     */
    public void setProperties(Map<String, String> properties) {
        this.properties = properties;
    }

    /**
     * Returns a string representation of this ParkingRequest.
     *
     * @return string representation of the ParkingRequest
     */
    @Override
    public String toString() {
        return "ParkingRequest{" +
                "command='" + command + '\'' +
                ", properties=" + properties +
                '}';
    }

    /**
     * Serializes this ParkingRequest to a JSON string.
     *
     * @return a JSON representation of this request
     */
    public String toJson() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }

    /**
     * Deserializes a JSON string into a ParkingRequest object.
     *
     * @param json the JSON string to deserialize
     * @return the resulting ParkingRequest object
     */
    public static ParkingRequest fromJson(String json) {
        Gson gson = new Gson();
        return gson.fromJson(json, ParkingRequest.class);
    }
}