package ict4315.parking.clients;

import ict4315.parking.protocol.ParkingResponse;
import ict4315_assignment_1.*;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

/**
 * The ServerClient class is a console-based client application that connects
 * to a parking system server over TCP. It collects user input, builds a
 * RegisterCustomerCommand, and communicates with the server using
 * Java object serialization.
 *
 * This client uses ObjectOutputStream to send serialized Command
 * objects and ObjectInputStream to receive ParkingResponse
 * objects in return.
 *
 * This implementation replaces earlier line-by-line string command parsing
 * with a type-safe, extensible object protocol based on Java serialization.
 */

public class ServerClient {
	
    /**
     * Starts the client application, connects to the local server at port 8080,
     * prompts the user for customer information, constructs a
     * RegisterCustomerCommand, sends it to the server, and processes the response.
     *
     * @param args command-line arguments (not used)
     */
	
	public static void main(String[] args) {
	    try (Socket socket = new Socket("localhost", 8080);
	         ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
	         ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
	         Scanner scanner = new Scanner(System.in)) {

	        System.out.println("Enter customer details (id first last phone# address):");
	        String id = scanner.next();
	        String firstName = scanner.next();
	        String lastName = scanner.next();
	        String phone = scanner.next();
	        String addressDetail = scanner.next();

            // Create address (hardcoded for simplicity; adjust as needed)
	        Address address = new Address("123 Main St", null, "GradTown", "CO", "80000");
            
	        // Create a Customer object
	        Customer customer = new Customer(id, firstName, lastName, phone, address);

            // Create a ParkingOffice and register the customer via a command
	        ParkingOffice office = new ParkingOffice(addressDetail, address, null);
	        Command command = new RegisterCustomerCommand(office);
	        
	        // Send the command to the server
	        out.writeObject(command);
	        out.flush();

            // Await and interpret server response
	        Object response = in.readObject();
	        if (response instanceof ParkingResponse) {
	        	ParkingResponse serverResponse = (ParkingResponse) response;
	            System.out.println("Client received: " + serverResponse.getMessage());
	        } else {
	            System.out.println("Unexpected response from server.");
	        }

	    } catch (IOException | ClassNotFoundException e) {
	        e.printStackTrace();
	    }
	}
}
