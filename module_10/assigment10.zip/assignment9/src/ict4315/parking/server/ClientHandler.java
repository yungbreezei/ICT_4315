package ict4315.parking.server;

import ict4315.parking.protocol.ParkingResponse;
import ict4315_assignment_1.Command;
import ict4315_assignment_1.ParkingService;

import java.io.*;
import java.net.Socket;

/**
 * The ClientHandler class manages a single client connection in its own thread.
 * It deserializes a Command object sent by the client, delegates execution
 * to the ParkingService, and sends back a ParkingResponse.
 *
 * The protocol is based on serialized Java objects using ObjectInputStream and
 * ObjectOutputStream}. Commands from the client must implement the Command
 * interface and be executable using the service layer.
 * Supported commands include:
 *     CUSTOMER – Registers a customer (first name, last name, email)
 *     CAR – Registers a car for an existing customer
 *     PARK – Logs a parking event for a car
 *     EXIT – Ends the session
 */
public class ClientHandler implements Runnable {

    private final Socket clientSocket;
    private final ParkingService service; 

    /**
     * Constructs a new ClientHandler for the given client socket and service layer.
     *
     * @param clientSocket The socket connected to the client.
     * @param service      The ParkingService used to execute parking-related commands.
     */
    
    public ClientHandler(Socket clientSocket, ParkingService service) {
        this.clientSocket = clientSocket;
        this.service = service;
    }
    
    /**
     * Handles the client interaction in a dedicated thread. It reads a serialized Command,
     * executes it using the provided ParkingService, and sends a ParkingResponse.
     * 
     * If an invalid object or unexpected exception occurs, the client receives an error response
     * with a specific status code.
     * 
     */
    @Override
    public void run() {
        long startTime = System.currentTimeMillis();

        try (
                ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
                ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream())
            ) {
        	
        	// Read request from client
            Object request = in.readObject();
            
            // Basic command handling 
            if (request instanceof Command) {
                Command command = (Command) request;
                String result = command.execute(service); 
                out.writeObject(new ParkingResponse());
            } else {
                out.writeObject(new ParkingResponse(3, "Invalid command type received"));
            }
            
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error handling client: " + e.getMessage());
            try (ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream())) {
                out.writeObject(new ParkingResponse(4, "Server error: " + e.getMessage()));
            } catch (IOException ioException) {
                System.err.println("Failed to send error response to client.");
            }
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                System.err.println("Failed to close socket: " + e.getMessage());
            }

            long endTime = System.currentTimeMillis();
            System.out.printf("%s handled client in: %d ms%n",
                Thread.currentThread().getName(),
                endTime - startTime
            );
        }
    }
}