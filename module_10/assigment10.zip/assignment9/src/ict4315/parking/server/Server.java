package ict4315.parking.server;

import java.io.*;
import java.net.*;
import java.util.Map;

import com.google.gson.Gson;
import ict4315.parking.protocol.ParkingRequest;
import ict4315.parking.protocol.ParkingResponse;

/**
 * The Server class listens on a specified port (default 8080) for client connections.
 * It uses a multi-threaded approach where each incoming client is handled by a ClientHandler.
 * 
 * The server expects client messages formatted as JSON strings using the
 * ParkingRequest protocol and responds with JSON-encoded ParkingResponse objects.
 *
 * This approach replaces the older line-by-line custom protocol with a standardized,
 * extensible, and robust JSON-based messaging system.
 * 
 */
public class Server {
	
    /**
     * Main entry point of the server application.
     * Starts a ServerSocket on port 8080 and waits for incoming connections.
     * Each connection is handled in its own thread via handleClient.
     *
     * @param args command-line arguments (not used)
     */
		
    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(8080)) {
            System.out.println("Parking Server started on port 8080");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                new Thread(() -> handleClient(clientSocket)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Handles communication with a single client socket.
     * This includes reading a JSON-formatted request, processing it,
     * and sending back a JSON-formatted response.
     *
     * @param socket The connected client socket.
     */
    private static void handleClient(Socket socket) {
    	try (
    	        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    	        PrintWriter out = new PrintWriter(socket.getOutputStream(), true)
    	) {
            Gson gson = new Gson();
            
            String json = in.readLine(); // read one line of JSON
            
            if (json == null || json.isBlank()) {
                System.err.println("Empty or null input from client");
                return;
            }
            
            System.out.println("\nReceived from client: " + json);

            if (json == null || json.isBlank()) {
                System.err.println("Received blank or null JSON from client");
                out.println(gson.toJson(new ParkingResponse(1, "Empty request")));
                return;
            }

            
            ParkingRequest request = null;
            try {
                request = gson.fromJson(json, ParkingRequest.class);
            } catch (Exception e) {
                System.err.println("Failed to parse JSON from client: " + json);
                e.printStackTrace();
                out.println(gson.toJson(new ParkingResponse(1, "Invalid JSON format")));
                return; // early exit to avoid NPE
            }
            
            String command = request.getCommand();
            Map<String, String> props = request.getProperties();
            
            ParkingResponse response;
            if ("CUSTOMER".equalsIgnoreCase(command)) {
                String name = props.get("firstname");
                response = new ParkingResponse(0, "Customer " + name + " registered.");
            } else {
                response = new ParkingResponse(1, "Unknown command: " + command);
            }

            String jsonResponse = gson.toJson(response);
            System.out.println("Sending response: " + jsonResponse);

            out.println(jsonResponse);  // This ensures a line is written
            out.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


