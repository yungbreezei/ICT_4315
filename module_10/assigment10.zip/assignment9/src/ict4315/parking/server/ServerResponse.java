package ict4315.parking.server;

import java.io.Serializable;

public class ServerResponse implements Serializable {
    private final String message;
    private final boolean success;

    public ServerResponse(String message, boolean success) {
        this.message = message;
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public boolean isSuccess() {
        return success;
    }

    @Override
    public String toString() {
        return (success ? "SUCCESS: " : "FAILURE: ") + message;
    }
}
