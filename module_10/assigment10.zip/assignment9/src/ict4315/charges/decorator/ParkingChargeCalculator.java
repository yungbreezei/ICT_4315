package ict4315.charges.decorator;

import java.time.LocalDateTime;

import com.google.inject.Inject;

import ict4315_assignment_1.Money;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;


/**
 * Abstract base class for calculating parking charges.
 *
 * Subclasses must implement the getParkingCharge(LocalDateTime, LocalDateTime, 
 * ParkingLot, ParkingPermit)}
 * method to define specific pricing strategies (flat rate, discounts, time-based pricing).
 *
 * This class is commonly used in the Decorator Pattern, allowing dynamic extension
 * of behavior without modifying the base structure.
 * }
 */
public abstract class ParkingChargeCalculator {

    /**
     * Calculates the parking charge for a given parking session.
     *
     * @param startTime the date and time when parking started
     * @param endTime the date and time when parking ended
     * @param lot the ParkingLot where the car was parked
     * @param permit the ParkingPermit used for the parking session
     * @return a Money object representing the total calculated charge
     */
	
	@Inject
	public abstract Money getParkingCharge(LocalDateTime startTime, LocalDateTime endTime, 
			ParkingLot lot, ParkingPermit permit);
	
}
