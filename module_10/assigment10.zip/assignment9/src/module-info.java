/**
 * 
 */
/**
 * 
 */
module assignment_1 {
    requires org.junit.jupiter.api;
    requires junit;
    requires java.sql;
    requires gson;
    requires guice;

    opens ict4315.parking.common to gson;
    opens ict4315.parking.protocol to gson;

    exports ict4315_assignment_1 to guice;
    exports ict4315.guice to guice;
    exports ict4315.parking.charges.factory to guice;
}


