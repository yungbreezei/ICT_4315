/* Bria Wright
 * 
 * ICT 4315
 * Week 5 Assignment
 * May 4, 2025
 */

package ict4315_assignment_1;

import java.util.ArrayList;
import java.util.HashMap;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID; // Needed to generate unique transaction IDs

import com.google.inject.Inject;

import ict4315.parking.charges.factory.ParkingChargeStrategyFactory;
import ict4315.parking.charges.strategy.ParkingChargeStrategy;
import ict4315.parking.observer.ParkingEvent;


/**
 * Manages all parking transactions for the system.
 * 
 * Handles vehicle entry and exit events, calculates parking charges using
 * appropriate strategies, and keeps a record of all transactions.
 *
 * This class is notified of parking events (entries and exits) and uses a
 * ParkingChargeStrategyFactory to determine how to calculate charges
 * for different parking lots.
 * 
 */
public class TransactionManager {
	
    private List<ParkingTransaction> transactions; // List of all completed parking transactions
    
    // Factory used to get the correct ParkingChargeStrategy for a parking lot
    private ParkingChargeStrategyFactory strategyFactory;
    
    // Map to keep track of currently active (ongoing) entries by parking permit
    private Map<ParkingPermit, LocalDateTime> activeEntries;


	    // Constructor to initialize TransactionManager with a specific charge strategy factor
    	@Inject
	    public TransactionManager(ParkingChargeStrategyFactory strategyFactory) {
	    	
	        this.transactions = new ArrayList<>();
	        this.strategyFactory = strategyFactory; // strategyFactory the factory used to retrieve charge strategies
	        this.activeEntries = new HashMap<>();
	    }
	    
	    /*
	     * Getters
	     */
	    public List<ParkingTransaction> getTransactions() {
	        return new ArrayList<>(transactions); // Return a new list containing all stored transactions
	    }

	    
	    /*
	     * Setters
	     */
	    public void setTransactions(List<ParkingTransaction> transactions) {
	    	this.transactions = transactions;
	    }
	    
	    /**
	     * Processes a ParkingEvent. On entry, records the entry time. On exit,
	     * calculates the charge using the appropriate strategy and stores the transaction.
	     *
	     * @param event the parking event (entry or exit)
	     * @throws IllegalArgumentException if the event or its data is null, or no strategy is found
	     * @throws IllegalStateException    if no entry time was recorded before an exit
	     */
		public void park(ParkingEvent event) {
	    	
	        // Check for null values before proceeding
	        if (event == null || event.getPermit() == null || event.getLot() == null) {
	            throw new IllegalArgumentException("ParkingEvent or missing data.");
	        }
	        
	        ParkingPermit permit = event.getPermit();
	        ParkingLot lot = event.getLot();
	        LocalDateTime timestamp = event.getTimeStamp();

	        if (event.isEntry()) {
	            // Create a new ParkingTransaction for entry
	            ParkingTransaction transaction = new ParkingTransaction("", timestamp, timestamp, permit, lot, null);
	            
	            // Record entry time
	            activeEntries.put(permit, timestamp); 
	            System.out.println("Entry recorded for permit: " + permit.getId() 
	            + " at " + timestamp);
	        } else {
	        	
	            // Process exit time, Retrieve and remove the matching entry time
	            LocalDateTime entryTime = activeEntries.remove(permit); // remove to clear it
	            if (entryTime == null) {
	                throw new IllegalStateException("No entry recorded for permit: " + 
	            permit.getId());
	                
	            }
	            
	            System.out.println("Exit recorded for permit: " + permit.getId() + 
	            		" with entry at " + entryTime);

	            // Calculate the charge
	            ParkingChargeStrategy strategy = strategyFactory.getStrategyFor(lot);
	            if (strategy == null) {
	                throw new IllegalArgumentException("No charge strategy found for lot: " + 
	                		lot.getName());
	            }

	            Money baseRate = lot.getBaseRate();
	            Money chargedAmount = strategy.calculateCharge(permit, entryTime, 
	            		timestamp, baseRate);

	            // Create and store the transaction
	            ParkingTransaction transaction = new ParkingTransaction(
	                UUID.randomUUID().toString(),
	                entryTime,
	                timestamp,
	                permit,
	                lot,
	                chargedAmount
	            );

	            transactions.add(transaction);
	            
	            File dir = new File("lib");
	            if (!dir.exists()) {
	                dir.mkdirs();
	            }
	            try (BufferedWriter writer = new BufferedWriter(new FileWriter
	            		("lib/transactions.txt", true))) {
	                writer.write(transaction.getExitTime() + "," + transaction.getChargedAmount().getAmount());
	                writer.newLine();
	            } catch (IOException e) {
	                System.err.println("Error writing transaction to file: " + e.getMessage());
	            }
	        }    
	    }
	    
	    /**
	     * Calculates total parking charges accumulated by a specific permit.
	     *
	     * @param permit the parking permit to look up
	     * @return the total charges as a Money object
	     */
	    public Money getParkingCharges(ParkingPermit permit) {
	        double total = transactions.stream()
	                .filter(t -> t.getPermit().equals(permit))
	                .mapToDouble(t -> t.getChargedAmount().getAmount())
	                .sum();
	        
	        return new Money(total, "USD");
	    }
	    
	    /**
	     * Calculates total parking charges accumulated by a specific customer.
	     *
	     * @param customer the customer whose parking history is being queried
	     * @return the total charges as a Money object
	     * @throws IllegalArgumentException if the customer is null
	     */
	    public Money getParkingCharges(Customer customer) {
	        if (customer == null) {
	            throw new IllegalArgumentException("Customer cannot be null.");
	        }

	        double total = transactions.stream()
	                .filter(t -> t.getPermit().getCar().getOwner().equals(customer))
	                .mapToDouble(t -> t.getChargedAmount().getAmount())
	                .sum();
	        
	        return new Money(total, "USD");
	    }
	}
