/* Bria Wright
 * 
 * ICT 4315
 * Week 5 Assignment
 * May 4, 2025
 */

package ict4315_assignment_1;


import java.util.*;

import ict4315.parking.charges.factory.ParkingChargeStrategyFactory;
import ict4315.parking.observer.ParkingEvent;

import com.google.inject.Inject;
import com.google.inject.Provides;
import com.google.inject.Singleton;


public class ParkingOffice {

	private String parkingOfficeName; // Name of the parking office
    private List<Customer> listOfCustomers = new ArrayList<>(); // Stores customers
	private List<ParkingLot> listOfParkingLots = new ArrayList<>();; // Manages multiple parking lots
	private List<Car> listOfCars = new ArrayList<>(); // Stores the registered cars
	private Address parkingOfficeAddress; // Set up address variable
		
    private final PermitManager permitManager = new PermitManager();
    private final TransactionManager transactionManager;
    
    /**
     * Initializes a ParkingOffice with the provided name and address.
     * @param listOfCustomers 
     * @param listOfParkingLots 
     * @param officeName The name of the parking office.
     * @param address The address of the parking office.
     */
//    public ParkingOffice(String parkingOfficeName, Address parkingOfficeAddress,
//    		ParkingChargeStrategyFactory strategyFactory) {
//    	
//        this.parkingOfficeName = parkingOfficeName;
//        this.parkingOfficeAddress = parkingOfficeAddress;
//        this.transactionManager = new TransactionManager(strategyFactory);
//
//    }
    
    @Inject
    public ParkingOffice(String parkingOfficeName, Address parkingOfficeAddress,
                         ParkingChargeStrategyFactory strategyFactory) {
    	
        this.parkingOfficeName = parkingOfficeName;
        this.parkingOfficeAddress = parkingOfficeAddress;
        this.transactionManager = new TransactionManager(strategyFactory);

    }
    
    @Provides
    @Singleton
    public ParkingOffice provideParkingOffice(Address address, ParkingChargeStrategyFactory factory) {
        return new ParkingOffice("Main Office", address, factory);
    }
    
    /*
     * Getters
     */
    public String getParkingOfficeName() {
    	return parkingOfficeName;
    }
    
    public List<Customer> getListOfCustomers() {
        return new ArrayList<>(listOfCustomers); // Return a copy for encapsulation
    }
    
    public List<ParkingLot> getListOfParkingLots() {
    	return listOfParkingLots;
    }
    
    public List<Car> getListOfCars() {
    	return listOfCars;
    }
    
    public Address getParkingOfficeAddress() {
    	return parkingOfficeAddress;
    }
    public PermitManager getPermitManager() {
        return permitManager;
    }
    public TransactionManager getTransactionManager() {
        return transactionManager;
    }
    
    /*
     * Setters
     */
    public void setParkingOfficeName(String parkingOfficeName) {
    	this.parkingOfficeName = parkingOfficeName;
    }
    public void setListOfCustomers(List<Customer> listOfCustomers) {
    	this.listOfCustomers = listOfCustomers;
    }
    public void setListOfParkingLots(List<ParkingLot> listOfParkingLots) {
    	this.listOfParkingLots = listOfParkingLots;
    }
    public void setListOfCars(List<Car> listOfCars) {
    	this.listOfCars = listOfCars;
    }
    public void setParkingOfficeAddress(Address parkingOfficeAddress) {
    	this.parkingOfficeAddress = parkingOfficeAddress;
    }
    
    /*
     * Methods
     */	 
    // Register a customer with the parking office
    public String register(Customer customer) {
        // Check if the customer already exists
        for (Customer c : listOfCustomers) {
            if (c.getId().equals(customer.getId())) {
                return "Customer already exists";  // Return a message if the customer already exists
            }
        }
        
        
        // If the customer doesn't have an ID (i.e., new customer), generate one
        if (customer.getId() == null || customer.getId().isEmpty()) {
        	String customerId = UUID.randomUUID().toString();  // Generate ID if not provided
            customer.setId(customerId);
        }

        // Add customer to list
        listOfCustomers.add(customer);

        return "Customer registered successfully";  // Return success message
    }

    
    // Register a parking lot with the parking office
    public void register(ParkingLot lot) {
        listOfParkingLots.add(lot);
    }
    
    // Register a car and issue a parking permit
    public String register(Car car) {   	
        if (car == null) {
            throw new IllegalArgumentException("Car cannot be null");
        }
        if (car.getOwner() == null) {
            throw new IllegalArgumentException("Car must have an owner");
        }
        
        // Verify customer is registered by ID
        boolean customerRegistered = listOfCustomers.stream()
                .anyMatch(c -> c.getId().equals(car.getOwner().getId()));
        
        if (!customerRegistered) {
            throw new IllegalArgumentException("Customer not registered");
        }
        
        // Generate and assign parking permit
        ParkingPermit permit = permitManager.register(car);
        
        // Add car to the list of cars (Ensure listOfCars exists in your ParkingOffice class)
        listOfCars.add(car);

        // Return the success message instead of the permit ID
        return "Car registered successfully"; 
    }
    
    /**
     * Processes a parking event by validating the event and forwarding it to the TransactionManager.
     *
     * @param event the ParkingEvent to process, must not be null
     * @throws IllegalArgumentException if the event is null or if the parking lot is not registered
     */
    public void park(ParkingEvent event) {
        if (event == null) {
            throw new IllegalArgumentException("ParkingEvent cannot be null.");
        }
        if (!listOfParkingLots.contains(event.getLot())) {
            throw new IllegalArgumentException("Parking lot not registered.");
        }
        transactionManager.park(event);
    }

    /**
     * Retrieves the total parking charges associated with a specific parking permit.
     *
     * @param permit the ParkingPermit to query
     * @return the total parking charges for the given permit
     */
    public Money getParkingCharges(ParkingPermit permit) {
        return transactionManager.getParkingCharges(permit);
    }

    /**
     * Retrieves the total parking charges associated with a specific customer.
     *
     * @param customer the Customer to query
     * @return the total parking charges for the given customer
     */
    public Money getParkingCharges(Customer customer) {
        return transactionManager.getParkingCharges(customer);
    }
    
    /*
     *  The helper methods, such as checking if a customer exists or 
     *  getting a customer by ID, to make the code cleaner and more readable.
     */
    public boolean customerExists(String customerId) {
        return listOfCustomers.stream()
                .anyMatch(c -> c.getId().equals(customerId));
    }
    public Customer getCustomerById(String customerId) {
        return listOfCustomers.stream()
                .filter(c -> c.getId().equals(customerId))
                .findFirst()
                .orElse(null);
    }
}
