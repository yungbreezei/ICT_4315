/* Bria Wright
 * 
 * ICT 4315
 * Week 10 Assignment: Guice
 */

package ict4315_assignment_1;

import java.util.Arrays;
import java.util.Properties;
import com.google.inject.Inject;


public class RegisterCarCommand implements Command{
	
	private ParkingOffice office;

    /**
     * Constructor 
     */
//	public RegisterCarCommand(ParkingOffice office) {
//		
//		this.office = office;
//	}
	
	@Inject
	public RegisterCarCommand(ParkingOffice office) {
		
		this.office = office;
	}
	
    /*
     * Getters 
     */
	public ParkingOffice getOffice() {
		return office;
	}
	
    /*
     * Setters 
     */
	public void setOffice(ParkingOffice office) {
		this.office = office;
	}
	

    public void checkParameters(Properties params) {
        if (params.getProperty("customerId") == null ||
            params.getProperty("licensePlate") == null ||
            params.getProperty("carType") == null) {
            throw new IllegalArgumentException("Missing required parameters");
        }
    }
	
    @Override
    public String execute(Properties props) {
        checkParameters(props);  // Call the validation method

        String customerId = props.getProperty("customerId");
        String licensePlate = props.getProperty("licensePlate");
        String carType = props.getProperty("carType");
        
        Customer owner = office.getListOfCustomers().stream()
                .filter(c -> c.getId().equals(customerId))
                .findFirst()
                .orElse(null);

            if (owner == null) {
                throw new IllegalArgumentException("Customer not found");
            }

            CarType type;
            try {
                type = CarType.valueOf(carType.toUpperCase());
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("Invalid car type: " + carType);
            }

            Car car = new Car(type, licensePlate, owner);
            return office.register(car);
    }

    @Override
    public String getCommandName() {
        return "RegisterCar";
    }

    @Override
    public String getDisplayName() {
        return "Register Car";
    }

    @Override
    public String execute(ParkingService service) {
        service.register(this);  
        return "Command executed";  
    }

}
