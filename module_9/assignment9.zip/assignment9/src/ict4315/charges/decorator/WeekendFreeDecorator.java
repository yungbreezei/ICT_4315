package ict4315.charges.decorator;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.Month;

import ict4315_assignment_1.Money;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;

public class WeekendFreeDecorator extends ParkingChargeCalculatorDecorator{
	
    /**
     * Constructs a WeekendFreeDecorator that wraps the given {@link ParkingChargeCalculator}.
     *
     * @param component the base calculator to wrap
     */
	public WeekendFreeDecorator(ParkingChargeCalculator component) {
		super(component);
	}
	
    /**
     * Returns a parking charge of $0.00 if the start time falls on a Saturday or Sunday
     * and is not graduation day. Otherwise, delegates to the wrapped calculator.
     *
     * @param startTime the start time of the parking session
     * @param endTime the end time of the parking session
     * @param lot the ParkingLot} being used
     * @param permit the ParkingPermit associated with the car
     * @return the calculated parking charge
     */
	@Override
	public Money getParkingCharge(LocalDateTime startTime, LocalDateTime endTime, ParkingLot lot,
			ParkingPermit permit) {
		
		DayOfWeek day = startTime.getDayOfWeek();
		Money baseCharge = component.getParkingCharge(startTime, endTime, lot, permit);
		
        if ((day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) && 
        !(isGraduationDay(startTime))) {
        	
            return new Money(0.00, "USD");
        }
        
		return baseCharge;
	}
	
    /**
     * Determines if the given date is graduation day (May 10, 2025).
     *
     * @param startTime the date to check
     * @return true if the date is graduation day, false otherwise
     */
	private boolean isGraduationDay(LocalDateTime startTime) {
		
        return startTime.getMonth() == Month.MAY && startTime.getDayOfMonth() == 10 && 
        		startTime.getYear() == 2025;
    }

}
