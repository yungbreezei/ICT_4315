package ict4315.parking.server;

import java.util.Map;

import ict4315.parking.protocol.ParkingRequest;
import ict4315.parking.protocol.ParkingResponse;

/**
 * The RequestHandler class is a utility responsible for processing
 * incoming ParkingRequest objects and returning structured
 * ParkingResponse} objects.
 * 
 * This class serves as the command dispatcher for the server's JSON-based
 * protocol. It interprets the command name and any associated key-value
 * properties, then executes the corresponding logic.
 *
 */

public class RequestHandler {
	
    /**
     * Processes a given {@code ParkingRequest} and returns an appropriate
     * ParkingResponse.
     *
     * @param request the parsed ParkingRequest containing a command and parameters
     * @return a ParkingResponse representing the result of executing the request
     */
	
    public static ParkingResponse handle(ParkingRequest request) {
        String command = request.getCommand();
        Map<String, String> props = request.getProperties();

        if ("CUSTOMER".equalsIgnoreCase(command)) {
            String name = props.get("firstname");
            return new ParkingResponse(0, "Customer " + name + " registered.");
        } else {
            return new ParkingResponse(1, "Unknown command: " + command);
        }
    }
	
}
