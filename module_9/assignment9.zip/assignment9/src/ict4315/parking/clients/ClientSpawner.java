package ict4315.parking.clients;

import java.io.*;
import java.net.Socket;

import com.google.gson.Gson;

import ict4315.parking.protocol.ParkingResponse;

/**
 * The ClientSpawner class is a multithreaded test harness that spawns multiple
 * simulated clients to test the performance and concurrency handling of a parking server.
 * 
 * Each client creates a socket connection to the server at localhost:8080, sends
 * a JSON-formatted CUSTOMER registration command, and then waits for a JSON-formatted
 * ParkingResponse.
 * 
 * This class is useful for stress-testing the server under concurrent load and for verifying
 * correctness and response times when handling multiple simultaneous connections.
 * 
 */

public class ClientSpawner {
	
    /**
     * Entry point for the test harness. Spawns a fixed number of client threads,
     * each of which sends a CUSTOMER registration request to the parking server
     * using JSON over a socket.
     *
     * @param args command-line arguments (not used)
     */
	
    public static void main(String[] args) {
    	
        int numClients = 5; // Number of concurrent clients to spawn
        Gson gson = new Gson(); // JSON serializer/deserializer
        
        for (int i = 0; i < numClients; i++) {
        	
            int clientId = i;
            new Thread(() -> {
                try (
                    Socket socket = new Socket("localhost", 8080);
                	BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
                	PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);
                ) {

                    // Build JSON request string
                	String jsonRequest = String.format(
                		    "{\"command\":\"CUSTOMER\",\"properties\":{\"firstname\":\"User%d\",\"lastname\":\"Test\",\"email\":\"user%d@example.com\"}}",
                		    clientId, clientId
                		);
                	
                	System.out.println("Client " + clientId + " sending request: " + jsonRequest);

                       long start = System.currentTimeMillis();
                       
                       // Send request to server
                       out.println(jsonRequest); // println adds newline and flushes
                       out.flush();
                       
                       // Read and parse response
                       String responseJson = in.readLine();
                       long end = System.currentTimeMillis();

                       if (responseJson == null) {
                           System.out.printf("Client %d handled in %d ms. Received null response%n",
                                   clientId, (end - start));
                       } else {
                           ParkingResponse response = gson.fromJson(responseJson, ParkingResponse.class);
                           System.out.printf("Client %d handled in %d ms. Status: %d, Message: %s%n",
                                   clientId, (end - start), response.getStatusCode(), response.getMessage());
                       }                   
                     
                } catch (IOException e) {
                    System.err.printf("Client %d encountered error: %s%n", clientId, e.getMessage());
                    e.printStackTrace();
                }
            }).start();
        }
    }
}

