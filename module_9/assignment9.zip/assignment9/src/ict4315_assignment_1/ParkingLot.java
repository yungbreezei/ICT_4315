/* Bria Wright
 * 
 * ICT 4315
 * Week 5 Assignment: Translating UML into Code
 * May 4, 2025
 */

package ict4315_assignment_1;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import ict4315.parking.charges.strategy.ParkingChargeStrategy;
import ict4315.parking.observer.ParkingAction;
import ict4315.parking.observer.ParkingEvent;

/**
 * Represents a parking lot in the system, including identification, address, pricing strategy,
 * and event notification functionality.
 */

public class ParkingLot {
		
		// Attributes
		private String id; // Unique identifier for the parking lot
		private String name; // Name for the parking lot
		private Address address; // Physical address of the parking lot
		
		private ParkingChargeStrategy chargeStrategy; // adding field to hold strategy
		private Money baseRate; // Base rate used as a foundation for charge strategies
	    private int capacity; // Parking lot car capacity
	    
	    private final List<ParkingAction> observers = new ArrayList<>();


	    /**
	     * Constructor to initialize a ParkingLot.
	     */
	    // Constructor with ParkingChargeStrategy
	    public ParkingLot(String id, String name, Address address, 
	    		ParkingChargeStrategy chargeStrategy, double baseRate, int capacity) {
	        this.id = id;
	        this.name = name;
	        this.address = address;
	        this.chargeStrategy = chargeStrategy;
	        this.baseRate = new Money(baseRate, "USD");
	        this.capacity = capacity;
	    }
	    
	    /*
	     * Getters
	     */
	    public String getId() {
	    	return id;
	    }
	    public String getName() {
	    	return name;
	    }
	    public Address getAddress() {
	    	return address;
	    }
	    public Money getBaseRate() {
	        return baseRate;
	    }
	    public ParkingChargeStrategy getChargeStrategy() {
	    	return this.chargeStrategy;
	    }
	    public int getCapacity() {
	        return capacity;
	    }
	    
	    
	    /*
	     * Setters
	     */	    
	    public void setId(String id) {
	    	this.id = id;
	    }
	    public void setName(String name) {
	    	this.name = name;
	    }
	    public void setAddress(Address address) {
	    	this.address = address;
	    }
	    public void setBaseRate(Money baseRate) {
	        this.baseRate = baseRate;
	    }
	    public void setChargeStrategy(ParkingChargeStrategy strategy) {
	        this.chargeStrategy = strategy;
	    }
	    public void setCapacity(int capacity) {
	        this.capacity = capacity;
	    }    

   
	    /*
	     * Methods
	     */	 

	    /**
	     * Returns a daily rate based on the car type.
	     * 
	     * @param carType type of the car (SUV or COMPACT)
	     * @return Money representing the daily rate
	     */
	    public Money getDailyRate(CarType carType) {
	    	
	    	// Base daily rate based on car type, with flexibility to change in the future
	        return new Money(carType == CarType.SUV ? 15.00 : 10.00, "USD");
	    }
	    
	    /**
	     * Calculates the charge for a given parking session.
	     * 
	     * @param permit     the ParkingPermit used
	     * @param entryTime  the time the vehicle entered
	     * @param exitTime   the time the vehicle exited
	     * @return the calculated Money charge
	     */
	    public Money calculateCharge(ParkingPermit permit, LocalDateTime entryTime, 
	            LocalDateTime exitTime) {
	        
	        CarType carType = permit.getCar().getType(); // Get car type from permit
	        Money baseRate = getDailyRate(carType);      // Get base rate based on type

	        return chargeStrategy.calculateCharge(permit, entryTime, exitTime, baseRate);
	    }
	    
	    /**
	     * Checks whether the lot uses an hourly-based pricing model.
	     * 
	     * @return true- if hourly, false- otherwise
	     */
		public boolean isHourly() {
			return chargeStrategy.isHourlyBased();
		}
		
	    /**
	     * Registers an observer for parking events.
	     * 
	     * @param observer an object implementing ParkingAction
	     */
	    public void addObserver(ParkingAction observer) {
	        observers.add(observer);
	    }
	    
	    /**
	     * Unregisters an observer from parking events.
	     * 
	     * @param observer the observer to remove
	     */
	    public void removeObserver(ParkingAction observer) {
	        observers.remove(observer);
	    }
	    
	    /**
	     * Notifies all registered observers of a parking event.
	     * 
	     * @param event the ParkingEvent to broadcast
	     */
	    private void notifyObservers(ParkingEvent event) {
	        System.out.println("Notifying observers of event: " + event);
	        for (ParkingAction observer : observers) {
	            observer.update(event);
	        }
	    }
	    
	    /**
	     * Triggers a vehicle entry event and notifies observers.
	     * 
	     * @param permit the permit of the entering vehicle
	     * @param time   the time of entry
	     */
	    public void enter(ParkingPermit permit, LocalDateTime time) {
	        notifyObservers(new ParkingEvent(permit, this, time, true));
	    }

	    /**
	     * Triggers a vehicle exit event and notifies observers.
	     * 
	     * @param permit the permit of the exiting vehicle
	     * @param time   the time of exit
	     */
	    public void exit(ParkingPermit permit, LocalDateTime time) {
	        notifyObservers(new ParkingEvent(permit, this, time, false));
	    }

	    /**
	     * Compares this parking lot with another for equality based on ID
	     * 
	     * @param o the other object
	     * @return true if IDs match, false otherwise
	     */
	    @Override
	    public boolean equals(Object o) {
	        if (this == o) return true;
	        if (o == null || getClass() != o.getClass()) return false;
	        ParkingLot parkingLot = (ParkingLot) o;
	        return Objects.equals(id, parkingLot.id);
	    }
	    // hash code based on lot ID
	    @Override
	    public int hashCode() {
	        return Objects.hash(id); // return hash code as integer
	    }
	    
	    @Override
	    public String toString() {
	    	// return formatted string of lot info
	        return "Parking Lot{" +
	                "Parking Lot id='" + id + '\'' +
	                ", Parking Lot Name='" + name + '\'' +
	                ", Parking Lot Address='" + address + '\'' +
	                '}';
	    }

	}