/* Bria Wright
 * 
 * ICT 4315
 * Week 1 Assignment: Translating UML into Code
 * April 6, 2025
 */

package ict4315_assignment_1;

//Enum to define the types of cars that can be parked in the parking lot
public enum CarType {
	
	    COMPACT, SUV;
}
