package ict4315.parking.observer;

import java.time.LocalDateTime;

import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;


/**
 * Represents an event in a parking system, such as a vehicle entering or exiting a parking lot.
 * 
 * The ParkingEvent contains information about the parking permit involved, 
 * the parking lot, the timestamp of the event, and whether it was an entry or exit event.
 * 
 */

public class ParkingEvent {
	
	private final ParkingPermit permit;
	private final ParkingLot lot;
	private final LocalDateTime timeStamp;
	private final boolean isEntry;
	
    /**
     * Constructs a new ParkingEvent.
     *
     * @param permit     the parking permit associated with the vehicle
     * @param lot        the parking lot where the event occurred
     * @param timeStamp  the date and time of the event
     * @param isEntry    true- if the event is an entry; false- if it is an exit
     */
	
	public ParkingEvent(ParkingPermit permit, ParkingLot lot, 
			LocalDateTime timeStamp, boolean isEntry) {
		
		this.permit = permit;
		this.lot = lot;
		this.timeStamp = timeStamp;
		this.isEntry = isEntry;
	}
	
	/*
	 * Getters
	 */
	public ParkingPermit getPermit() {
		return permit;
	}
	public ParkingLot getLot() {
		return lot;
	}
	public LocalDateTime getTimeStamp() {
		return timeStamp;
	}
	public boolean isEntry() {
		return isEntry;
	}
}
