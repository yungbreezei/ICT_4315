package ict4315.parking.observer;

import java.util.List;

import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.TransactionManager;

public class ParkingObserver implements ParkingAction{

	private final TransactionManager transactionManager;
	
    /**
     * Registers it with a list of parking lots.
     *
     * @param transactionManager the transaction manager responsible for handling parking events
     * @param lots               the list of parking lots this observer should monitor
     */
	
	public ParkingObserver(TransactionManager transactionManager, List<ParkingLot> lots) {
		
	    this.transactionManager = transactionManager;

	    // Ensure ParkingObserver registers with all lots
	    for (ParkingLot lot : lots) {
	        lot.addObserver(this); // Register the current instance (this) as the observer
	    }
	}

    /**
     * When a parking event occurs (entry or exit).
     * This method delegates the event to the TransactionManager.
     *
     * @param event the parking event containing permit, lot, timestamp, and entry/exit info
     */
	@Override
	public void update(ParkingEvent event) {
		transactionManager.park(event);		
	}
}
