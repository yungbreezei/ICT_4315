package ict4315.parking.server;

import com.google.gson.Gson;
import ict4315.parking.protocol.ParkingRequest;
import ict4315.parking.protocol.ParkingResponse;
import ict4315_assignment_1.Command;
import ict4315_assignment_1.ParkingService;

import java.io.*;
import java.net.Socket;

/**
 * The ClientHandler class is responsible for processing a single client connection.
 * It reads a JSON-encoded ParkingRequest, dispatches the appropriate handler,
 * and returns a JSON-encoded ParkingResponse to the client.
 *
 * Supported commands include:
 *     CUSTOMER – Registers a customer with firstname, lastname, and email
 *     CAR – Registers a car linked to a customer ID
 *     PARK – Simulates parking a car in a specific lot
 *     EXIT – Closes the connection
 */
public class ClientHandler implements Runnable {

    private final Socket clientSocket;
    private final ParkingService service; 

    public ClientHandler(Socket clientSocket, ParkingService service) {
        this.clientSocket = clientSocket;
        this.service = service;
    }
    
/**
 * Starts the thread and handles the client interaction using JSON-based protocol.
 * Reads input, parses JSON into ParkingRequest executes appropriate logic,
 * and sends back a JSON-formatted ParkingResponse.
 */
    @Override
    public void run() {
        long startTime = System.currentTimeMillis();

        try (
                ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
                ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream())
            ) {
        	
        	// Read request from client
            Object request = in.readObject();
            
            // Basic command handling 
            if (request instanceof Command) {
                Command command = (Command) request;
                String result = command.execute(service); 
                out.writeObject(new ServerResponse(result, true));
            } else {
                out.writeObject(new ServerResponse("Invalid command type received", false));
            }
            
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error handling client: " + e.getMessage());
            try (ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream())) {
                out.writeObject(new ServerResponse("Server error: " + e.getMessage(), false));
            } catch (IOException ioException) {
                System.err.println("Failed to send error response to client.");
            }
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                System.err.println("Failed to close socket: " + e.getMessage());
            }

            long endTime = System.currentTimeMillis();
            System.out.printf("%s handled client in: %d ms%n",
                Thread.currentThread().getName(),
                endTime - startTime
            );
        }
    }
    
    private void logTiming(long durationMillis) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("lib/thread_timing.txt", true))) {
            writer.write("Thread " + Thread.currentThread().getName() +
                         " handled client in: " + durationMillis + " ms");
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error logging timing info: " + e.getMessage());
        }
    }
}
