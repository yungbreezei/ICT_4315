package ict4315.parking.server;

import com.google.gson.Gson;
import ict4315.parking.protocol.ParkingRequest;
import ict4315.parking.protocol.ParkingResponse;

import java.io.*;
import java.net.Socket;

/**
 * The ClientHandler class is responsible for processing a single client connection.
 * It reads a JSON-encoded ParkingRequest, dispatches the appropriate handler,
 * and returns a JSON-encoded ParkingResponse to the client.
 *
 * Supported commands include:
 *     CUSTOMER – Registers a customer with firstname, lastname, and email
 *     CAR – Registers a car linked to a customer ID
 *     PARK – Simulates parking a car in a specific lot
 *     EXIT – Closes the connection
 */
public class ClientHandler implements Runnable {

    private final Socket clientSocket;
    private final Server server; // to call server.handleRequest()

    public ClientHandler(Socket socket, Server server) {
        this.clientSocket = socket;
        this.server = server;
    }
    
/**
 * Starts the thread and handles the client interaction using JSON-based protocol.
 * Reads input, parses JSON into ParkingRequest executes appropriate logic,
 * and sends back a JSON-formatted ParkingResponse.
 */
    @Override
    public void run() {
        long startTime = System.nanoTime();

        try (
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            Gson gson = new Gson();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                ParkingRequest request = gson.fromJson(inputLine, ParkingRequest.class);
                ParkingResponse response = server.handleRequest(request);
                out.println(gson.toJson(response));
            }

        } catch (IOException e) {
            System.err.println("Client error: " + e.getMessage());
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                System.err.println("Error closing socket: " + e.getMessage());
            }

            long endTime = System.nanoTime();
            long durationMillis = (endTime - startTime) / 1_000_000;

            logTiming(durationMillis); // ✅ Save timing to file
        }
    }
    
    private void logTiming(long durationMillis) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("lib/thread_timing.txt", true))) {
            writer.write("Thread " + Thread.currentThread().getName() +
                         " handled client in: " + durationMillis + " ms");
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error logging timing info: " + e.getMessage());
        }
    }
}
