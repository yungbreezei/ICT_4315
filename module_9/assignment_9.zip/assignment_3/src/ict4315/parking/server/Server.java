package ict4315.parking.server;

import java.io.*;
import java.net.*;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.gson.Gson;
import ict4315.parking.common.CommandMessage;
import ict4315.parking.observer.ParkingEvent;
import ict4315.parking.protocol.ParkingRequest;
import ict4315.parking.protocol.ParkingResponse;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;
import ict4315_assignment_1.TransactionManager;

/**
 * The Server class listens on a specified port (default 8080) for client connections.
 * It uses a multi-threaded approach where each incoming client is handled by a ClientHandler.
 * 
 * The server expects client messages formatted as JSON strings using the
 * ParkingRequest protocol and responds with JSON-encoded ParkingResponse objects.
 *
 * This approach replaces the older line-by-line custom protocol with a standardized,
 * extensible, and robust JSON-based messaging system.
 * 
 */
public class Server {
	
    /**
     * Main entry point of the server application.
     * Listens for connections and spawns a new ClientHandler thread for each client.
     *
     * @param args command-line arguments (not used)
     */
	
	private static final int PORT = 8080; // Chosen port
	private static final int THREAD_POOL_SIZE = 10;
	private final ExecutorService threadPool = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
	
    public static void main(String[] args) {
    	
        Server server = new Server();
        server.start();
    }
        
        // Start the server socket and accept connections
        public void start() {
            try (ServerSocket serverSocket = new ServerSocket(PORT)) {
                System.out.println("Server listening on port " + PORT);

                while (true) {
                    Socket clientSocket = serverSocket.accept();
                    System.out.println("Client connected: " + clientSocket.getInetAddress());

                    // Start new thread for this client and pass 'this' Server instance
                  // new Thread(new ClientHandler(clientSocket, this)).start();
             
                 /* This hands the ClientHandler Runnable to the pool instead of spinning up a 
                  *  new thread every time. 
                  */ 
                    threadPool.submit(new ClientHandler(clientSocket, this));                
                }
            } catch (IOException e) {
                System.err.println("Server error: " + e.getMessage());
            } finally {
                threadPool.shutdown(); // not strictly necessary if server runs forever
            }
        }

    // Handles a ParkingRequest and returns a ParkingResponse (can be tested)
    public ParkingResponse handleRequest(ParkingRequest request) {
        if (request == null || request.getCommand() == null) {
            return new ParkingResponse(1, "Invalid request");
        }

        String command = request.getCommand().toUpperCase();

        switch (command) {
            case "CUSTOMER":
                return handleCustomer(request);

            case "CAR":
                return handleCar(request);

            case "PARK":
                return handlePark(request);

            case "EXIT":
                return new ParkingResponse(0, "Goodbye!");

            default:
                return new ParkingResponse(1, "Unknown command: " + command);
        }
    }
    
    /**
     * Handles the CUSTOMER command. Validates required fields and simulates
     * registering a customer.
     *
     * @param request the parsed ParkingRequest
     * @return a ParkingResponse indicating success or error
     */
    private ParkingResponse handleCustomer(ParkingRequest request) {
        Map<String, String> props = request.getProperties();

        if (!props.containsKey("firstname") || !props.containsKey("lastname") || 
        		!props.containsKey("email")) {
            return new ParkingResponse(1, "Missing required customer fields");
        }

        String firstName = props.get("firstname");
        String lastName = props.get("lastname");
        String email = props.get("email");

        // TODO: Register the customer in your DB or data structure
        System.out.printf("Registering customer: %s %s, email: %s%n", firstName, lastName, email);

        return new ParkingResponse(0, "Customer registered successfully");
    }
    /**
     * Handles the CAR command. Validates input and simulates registering
     * a car for an existing customer.
     *
     * @param request the parsed ParkingRequest
     * @return a ParkingResponse indicating success or error
     */
    private ParkingResponse handleCar(ParkingRequest request) {
        Map<String, String> props = request.getProperties();

        if (!props.containsKey("license") || !props.containsKey("customer")) {
            return new ParkingResponse(1, "Missing required car fields");
        }

        String license = props.get("license");
        String customerId = props.get("customer");

        // TODO: Link car to customer in DB or memory
        System.out.printf("Registering car: %s for customer: %s%n", license, customerId);

        return new ParkingResponse(0, "Car registered successfully");
    }
    /**
     * Handles the PARK command. Validates input and simulates parking a vehicle.
     *
     * @param request the parsed ParkingRequest
     * @return a ParkingResponse indicating success or error
     */
    private ParkingResponse handlePark(ParkingRequest request) {
        Map<String, String> props = request.getProperties();

        String license = props.get("license");
        String lot = props.get("lot");

        if (license == null || lot == null) {
            return new ParkingResponse(1, "Missing license or lot");
        }

        // Simulate parking logic
        System.out.printf("Car %s parked in lot %s%n", license, lot);

        return new ParkingResponse(0, "Car parked successfully");
    }   
}


