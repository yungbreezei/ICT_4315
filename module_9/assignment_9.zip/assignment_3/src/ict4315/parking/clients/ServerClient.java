package ict4315.parking.clients;

import ict4315.parking.protocol.ParkingRequest;
import ict4315.parking.protocol.ParkingResponse;
import ict4315.parking.server.ServerResponse;
import ict4315_assignment_1.*;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;
/**
 * The ServerClient class is a simple client-side application that connects to
 * a parking server using a socket. It sends commands using a JSON-based protocol and
 * receives structured responses.
 *
 * The client prompts the user for input (e.g., "CUSTOMER firstname=Rob"),
 * construct ParkingRequest} object with the command and parameters,
 * serializes it to JSON, and sends it to the server. It then waits for a JSON
 * response, deserializes it into a ParkingResponse, and displays the result.
 *
 * This implementation replaces the previous line-by-line command format with
 * a more robust and structured JSON protocol.
 *
 * Example input:
 * CUSTOMER firstname=Rob lastname=Smith email=rob@example.com
 *
 * Example output:
 * Status: 0, Message: Customer created successfully
 * 
 */

public class ServerClient {
	
    /**
     * Starts the client application, connects to the server, and processes commands.
     * 
     * The client reads user input from the console, builds a ParkingRequest,
     * sends it as a JSON string, and then handles the ParkingResponse
     * received from the server.
     * 
     *
     * @param args command-line arguments (not used)
     */
	
	public static void main(String[] args) {
	    try (Socket socket = new Socket("localhost", 8080);
	         ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
	         ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
	         Scanner scanner = new Scanner(System.in)) {

	        System.out.println("Enter customer details (id first last phone# address):");
	        String id = scanner.next();
	        String firstName = scanner.next();
	        String lastName = scanner.next();
	        String phone = scanner.next();
	        String addressDetail = scanner.next();

	        // You can add additional parameters if your Customer class requires them
	        Address address = new Address("123 Main St", null, "GradTown", "CO", "80000");
	        Customer customer = new Customer(id, firstName, lastName, phone, address);

	        // Wrap the Customer in a Command
	        ParkingOffice office = new ParkingOffice(addressDetail, address, null);
	        Command command = new RegisterCustomerCommand(office);
	        
	        // Send the command to the server
	        out.writeObject(command);
	        out.flush();

	        // Read the response from the server
	        Object response = in.readObject();
	        if (response instanceof ServerResponse) {
	            ServerResponse serverResponse = (ServerResponse) response;
	            System.out.println("Client received: " + serverResponse.getMessage());
	        } else {
	            System.out.println("Unexpected response from server.");
	        }

	    } catch (IOException | ClassNotFoundException e) {
	        e.printStackTrace();
	    }
	}
}
