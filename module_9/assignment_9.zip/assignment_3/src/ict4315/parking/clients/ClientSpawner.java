package ict4315.parking.clients;

import java.io.*;
import java.net.Socket;

public class ClientSpawner {
	
    public static void main(String[] args) {
    	
        int numClients = 10;

        for (int i = 0; i < numClients; i++) {
        	
        	int clientId = i;
            new Thread(() -> {
                try (
                		Socket socket = new Socket("localhost", 8080);
                		BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        PrintWriter out = new PrintWriter(socket.getOutputStream(), true))
                        
                {

                       String jsonRequest = """
                           {
                             "command": "CUSTOMER",
                             "properties": {
                               "firstname": "User%d",
                               "lastname": "Test",
                               "email": "user%d@example.com"
                             }
                           }
                           """.formatted(clientId, clientId);

                       long start = System.currentTimeMillis();
                       
                       // Send request
                       out.println(jsonRequest);  // Adds newline and flushes
                       out.flush();
                       
                       // Read response line
                       String response = in.readLine();  // Waits for newline
                       long end = System.currentTimeMillis();

                       System.out.printf("Client %d handled in %d ms. Response: %s%n",
                    	        clientId, (end - start), response);
                       
                       System.out.println("Received from client: " + jsonRequest);
                       
                   } catch (IOException e) {
                       e.printStackTrace();
                   }
            }).start();
        }
    }
}

