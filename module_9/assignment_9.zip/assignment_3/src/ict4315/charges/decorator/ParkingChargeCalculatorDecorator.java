package ict4315.charges.decorator;


/**
 * Abstract base class for decorators that extend the functionality of a ParkingChargeCalculator.
 *
 * This class is part of the Decorator design pattern, allowing behavior to be added to a parking
 * charge calculation dynamically by wrapping another ParkingChargeCalculator instance.
 *
 * Concrete subclasses should override the getParkingCharge method to apply additional
 * rules or modifications (discounts, surcharges, time-based logic) while still delegating
 * the core calculation to the wrapped component. 
 * 
 */

public abstract class ParkingChargeCalculatorDecorator extends ParkingChargeCalculator {

    /**
     * The component being decorated. This is the calculator to which the
     * decorator will delegate calls, possibly adding behavior before or after.
     */
	
	protected final ParkingChargeCalculator component;
	
	
    /**
     * Constructs a decorator with the specified ParkingChargeCalculator component.
     *
     * @param component the parking charge calculator to be wrapped/decorated
     */
	
	public ParkingChargeCalculatorDecorator (ParkingChargeCalculator component) {
		this.component = component;
	}
	
}
