package ict4315.charges.decorator;

import java.time.LocalDateTime;
import java.time.Month;

import ict4315_assignment_1.Car;
import ict4315_assignment_1.CarType;
import ict4315_assignment_1.Money;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;

public class GraduationSurchargeDecorator extends ParkingChargeCalculatorDecorator{

    /**
     * The surcharge applied to qualifying vehicles on graduation day.
     */
	private static final Money GRADUATION_SURCHARGE = new Money(2.00, "USD");
	
	
    /**
     * Constructs a GraduationSurchargeDecorator that wraps the given 
     * ParkingChargeCalculator.
     *
     * @param component the base calculator to wrap
     */
	public GraduationSurchargeDecorator(ParkingChargeCalculator component) {
		super(component);
	}

    /**
     * Returns the calculated parking charge. If the parking date is graduation day (May 10, 2025)
     * and the car type is {@code COMPACT} or {@code SUV}, the graduation surcharge is added
     * to the base charge.
     *
     * @param startTime the start time of the parking session
     * @param endTime the end time of the parking session
     * @param lot the parking lot being used
     * @param permit the permit associated with the car
     * @return the total parking charge with graduation surcharge if applicable
     */
	@Override
	public Money getParkingCharge(LocalDateTime startTime, LocalDateTime endTime, ParkingLot lot,
			ParkingPermit permit) {
		
		Money baseCharge = component.getParkingCharge(startTime, endTime, lot, permit);
		Car car = permit.getCar();
		
		if (isGraduationDay(startTime) && 
			    (car.getType() == CarType.COMPACT || car.getType() == CarType.SUV)) {
			
			    baseCharge = baseCharge.add(GRADUATION_SURCHARGE);
			}
		return baseCharge;
	}
	
    /**
     * Determines if the given date is graduation day (May 10, 2025).
     *
     * @param date the date to check
     * @return true if it is graduation day, false otherwise
     */
    private boolean isGraduationDay(LocalDateTime date) {
    	// check the date & return if the date is May 10th
        return date.getMonth() == Month.MAY && date.getDayOfMonth() == 10 && 
        		date.getYear() == 2025;
    }

}
