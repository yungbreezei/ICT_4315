package ict4315.charges.decorator.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ict4315.charges.decorator.FlatRateCalculator;
import ict4315.charges.decorator.ParkingChargeCalculator;
import ict4315.charges.decorator.WeekendFreeDecorator;
import ict4315_assignment_1.Address;
import ict4315_assignment_1.Car;
import ict4315_assignment_1.CarType;
import ict4315_assignment_1.Customer;
import ict4315_assignment_1.Money;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;

/**
 * Sets up test data before each test, including a parking lot, a customer,
 * a compact car, and a valid parking permit.
 */
class WeekendFreeDecoratorTest {

    private ParkingLot lot;
    private Customer customer;
    private Car car;
    private ParkingPermit permit;

    @BeforeEach
    void setUp() {
    	Address address = new Address("123 Main St", null, "WeekendLot", "CO", "80000");
        lot = new ParkingLot("Lot X", "Standard Lot", address, null, 10.0, 50);
        customer = new Customer("C001", "Alice", "Smith", "123-456-7890", address);

        car = new Car(CarType.COMPACT, "SED789", customer);
        permit = new ParkingPermit("P3", car, LocalDateTime.now().plusDays(30));
    }
    
    /**
     * Tests that the parking charge is zero when parking occurs on a Saturday.
     *
     * Expected: $0.00
     */
    @Test
    void returnsZeroChargeOnSaturday() {
        ParkingChargeCalculator calculator = new WeekendFreeDecorator(
                new FlatRateCalculator(10.0, "USD")
        );

        Money charge = calculator.getParkingCharge(
                LocalDateTime.of(2025, 5, 17, 10, 0),  // Saturday
                LocalDateTime.of(2025, 5, 17, 12, 0),
                lot,
                permit
        );

        assertEquals(new Money(0.0, "USD"), charge);
    }
    
    /**
     * Tests that the parking charge is zero when parking occurs on a Sunday.
     *
     * Expected: $0.00
     */
    @Test
    void returnsZeroChargeOnSunday() {
        ParkingChargeCalculator calculator = new WeekendFreeDecorator(
                new FlatRateCalculator(10.0, "USD")
        );

        Money charge = calculator.getParkingCharge(
                LocalDateTime.of(2025, 5, 18, 14, 0),  // Sunday
                LocalDateTime.of(2025, 5, 18, 16, 0),
                lot,
                permit
        );

        assertEquals(new Money(0.0, "USD"), charge);
    }
    
    /**
     * Tests that the regular parking charge is applied on a weekday (Friday).
     *
     * Expected: $5/hour × 2 hours = $10.00
     */
    @Test
    void returnsRegularChargeOnWeekday() {
        ParkingChargeCalculator calculator = new WeekendFreeDecorator(
                new FlatRateCalculator(5.0, "USD")
        );

        Money charge = calculator.getParkingCharge(
                LocalDateTime.of(2025, 5, 9, 10, 0),  // Friday
                LocalDateTime.of(2025, 5, 9, 12, 0),
                lot,
                permit
        );

        assertEquals(new Money(10.0, "USD"), charge);
    }
}
