package ict4315.charges.decorator.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;

import ict4315.charges.decorator.FlatRateCalculator;
import ict4315.charges.decorator.GraduationSurchargeDecorator;
import ict4315.charges.decorator.ParkingChargeCalculator;
import ict4315_assignment_1.Address;
import ict4315_assignment_1.Car;
import ict4315_assignment_1.CarType;
import ict4315_assignment_1.Customer;
import ict4315_assignment_1.Money;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;

import org.junit.jupiter.api.Test;

/**
 * Sets up the common test data including a sample parking lot,
 * customer, compact car, and parking permit used in the tests.
 */

class GraduationSurchargeDecoratorTest {

    private ParkingLot lot;
    private Customer customer;
    private Car car;
    private ParkingPermit permit;

    @BeforeEach
    void setUp() {
    	Address address = new Address("123 Main St", null, "WeekendLot", "CO", "80000");
        lot = new ParkingLot("Lot C", "Campus", address, null, 15.0, 50);
        customer = new Customer("C001", "Ponea", "Up", "123-456-7890", address);

        car = new Car(CarType.COMPACT, "GRAD123", customer);
        permit = new ParkingPermit("P4", car, LocalDateTime.now().plusDays(30));
    }

    
    /**
     * Tests that the graduation surcharge is applied correctly on June 7, 2025,
     * which is designated as the graduation day.
     * 
     * Expected calculation:
     * Base rate: $15/hour * 2 = $30
     * Graduation surcharge: +$2 (added internally by decorator)
     * Final charge: $30.00
     */
    @Test
    void appliesSurchargeOnGraduationDay() {
        ParkingChargeCalculator calculator = new GraduationSurchargeDecorator(
                new FlatRateCalculator(15.0, "USD")
        );

        Money charge = calculator.getParkingCharge(
                LocalDateTime.of(2025, 6, 7, 9, 0),  // Graduation Day (June 7)
                LocalDateTime.of(2025, 6, 7, 11, 0),
                lot,
                permit
        );

        assertEquals(new Money(30.0, "USD"), charge);  // Double the flat rate
    }    
    
    /**
     * Tests that no graduation surcharge is applied on a normal day
     * (June 6, 2025), ensuring the base rate is charged without modification.
     * 
     * Expected: $15/hour * 2 = $30
     */
    @Test
    void doesNotApplySurchargeOnRegularDay() {
        ParkingChargeCalculator calculator = new GraduationSurchargeDecorator(
                new FlatRateCalculator(15.0, "USD")
        );

        Money charge = calculator.getParkingCharge(
                LocalDateTime.of(2025, 6, 6, 10, 0),  // Regular day
                LocalDateTime.of(2025, 6, 6, 12, 0),
                lot,
                permit
        );

        assertEquals(new Money(30.0, "USD"), charge);  // No surcharge
    }
}
