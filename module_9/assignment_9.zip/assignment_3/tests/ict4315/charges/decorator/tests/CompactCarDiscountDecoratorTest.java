package ict4315.charges.decorator.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ict4315_assignment_1.Address;
import ict4315_assignment_1.Car;
import ict4315_assignment_1.CarType;
import ict4315_assignment_1.Customer;
import ict4315_assignment_1.Money;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;
import ict4315.charges.decorator.ParkingChargeCalculator;
import ict4315.charges.decorator.FlatRateCalculator;
import ict4315.charges.decorator.CompactCarDiscountDecorator;

/**
 * Unit tests for the CompactCarDiscountDecorator class.
 *
 * These tests verify that the discount logic is correctly applied to compact cars
 * and not applied to other car types.
 * 
 * Uses FlatRateCalculator as the base charge calculator with a $5.00 hourly rate.
 */

class CompactCarDiscountDecoratorTest {
	
    private ParkingLot lot;
    private Customer customer;
    private Car compactCar;
    private Car suvCar;
    private ParkingPermit compactPermit;
    private ParkingPermit suvPermit;

    @BeforeEach
    void setUp() {
    	Address address = new Address("123 Main St", null, "GradTown", "CO", "80000");
        lot = new ParkingLot("Lot A", "Campus", address, null, 10.0, 50);
        customer = new Customer("C001", "Alice", "Smith", "123-456-7890", address);

        compactCar = new Car(CarType.COMPACT, "CMP123", customer);
        suvCar = new Car(CarType.SUV, "SUV456", customer);

        compactPermit = new ParkingPermit("P1", compactCar, LocalDateTime.now().plusDays(30));
        suvPermit = new ParkingPermit("P2", suvCar, LocalDateTime.now().plusDays(30));
    }
    /**
     * Test that a compact car receives a 20% discount on the parking charge.
     * 
     * Parking duration is 2 hours at $5/hour = $10. With a 20% discount, the expected charge is $8.00.
     */
	
	@Test
    void CompactCarGetsDiscount() {
		
        ParkingChargeCalculator calculator = new CompactCarDiscountDecorator(
                new FlatRateCalculator(5.0, "USD")
        );

        Money charge = calculator.getParkingCharge(
                LocalDateTime.of(2025, 5, 9, 9, 0),
                LocalDateTime.of(2025, 5, 9, 11, 0),
                lot,
                compactPermit
        );

        assertEquals(new Money(8.0, "USD"), charge);  // 20% discount on 10.0
    }

    /**
     * Test that a non-compact car (SUV) does not receive any discount.
     * 
     * Parking duration is 2 hours at $5/hour = $10. No discount should be applied.
     */
	
    @Test
    void NonCompactCarNoDiscount() {
        ParkingChargeCalculator calculator = new CompactCarDiscountDecorator(
                new FlatRateCalculator(10.0, "USD")
        );

        Money charge = calculator.getParkingCharge(
                LocalDateTime.of(2025, 5, 9, 9, 0),
                LocalDateTime.of(2025, 5, 9, 11, 0),
                lot,
                suvPermit
        );

        assertEquals(new Money(20.0, "USD"), charge);  // No discount
    }
}
