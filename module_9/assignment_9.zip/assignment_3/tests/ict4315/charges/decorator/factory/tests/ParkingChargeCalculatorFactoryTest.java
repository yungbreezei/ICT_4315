package ict4315.charges.decorator.factory.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ict4315.charges.decorator.ParkingChargeCalculator;
import ict4315.charges.decorator.factory.ParkingChargeCalculatorFactory;
import ict4315_assignment_1.Address;
import ict4315_assignment_1.Car;
import ict4315_assignment_1.CarType;
import ict4315_assignment_1.Customer;
import ict4315_assignment_1.Money;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;

/**
 * These tests check whether the correct decorators are applied when creating
 * parking charge calculators for various scenarios involving car type,
 * day of the week, and graduation events.
 * 
 */

class ParkingChargeCalculatorFactoryTest {

    private ParkingPermit compactPermit;
    private ParkingPermit suvPermit;
    private ParkingLot lot;
    private ParkingChargeCalculatorFactory factory;

    @BeforeEach
    void setUp() {
    	Address address = new Address("123 Main St", null, "GradTown", "CO", "80000");
        Customer customer = new Customer("C001", "Alice", "Smith", "123-456-7890", address);
        
        compactPermit = new ParkingPermit("P123", new Car(CarType.COMPACT, "123-ABC", customer), 
        		LocalDateTime.now().plusDays(30));
        
        suvPermit = new ParkingPermit("P456", new Car(CarType.SUV, "456-DEF", customer), 
        		LocalDateTime.now().plusDays(30));
        
        lot = new ParkingLot("Lot B", "Campus", address, null, 10.0, 50);
        factory = new ParkingChargeCalculatorFactory();
    }
    
    /**
     * Tests charge for a compact car parked on a regular weekday, outside the graduation period.
     * Expected: base rate with 20% compact car discount applied.
     */

    @Test
    void compactCarOnWeekdayNonGraduation() {
        ParkingChargeCalculator calculator = factory.createCalculator(
                lot,
                compactPermit,
                LocalDateTime.of(2025, 5, 6, 10, 0),
                LocalDateTime.of(2025, 5, 6, 12, 0)
        );
        Money charge = calculator.getParkingCharge(
                LocalDateTime.of(2025, 5, 6, 10, 0),
                LocalDateTime.of(2025, 5, 6, 12, 0),
                lot,
                compactPermit
        );
        assertEquals(new Money(16.0, "USD"), charge); // $10 with 20% discount
    }
    
    
    /**
     * Tests charge for an SUV parked on a weekend during the graduation period.
     * Expected: weekend-free parking overrides graduation surcharge.
     */
    @Test
    void suvOnWeekendDuringGraduation() {
        ParkingChargeCalculator calculator = factory.createCalculator(
                lot,
                suvPermit,
                LocalDateTime.of(2025, 6, 7, 10, 0),
                LocalDateTime.of(2025, 6, 7, 12, 0)
        );
        Money charge = calculator.getParkingCharge(
                LocalDateTime.of(2025, 6, 7, 10, 0),
                LocalDateTime.of(2025, 6, 7, 12, 0),
                lot,
                suvPermit
        );
        assertEquals(new Money(0.0, "USD"), charge); // Weekend free even during graduation
    }
    
    
    /**
     * Tests charge for a compact car on a weekday during the graduation period.
     * Expected: 20% discount plus graduation surcharge applied correctly.
     */
    @Test
    void compactCarDuringGraduationOnWeekday() {
        ParkingChargeCalculator calculator = factory.createCalculator(
                lot,
                compactPermit,
                LocalDateTime.of(2025, 6, 6, 10, 0),
                LocalDateTime.of(2025, 6, 6, 12, 0)
        );
        Money charge = calculator.getParkingCharge(
                LocalDateTime.of(2025, 6, 6, 10, 0),
                LocalDateTime.of(2025, 6, 6, 12, 0),
                lot,
                compactPermit
        );
        // $10 base - 20% compact = $8 + $2 graduation = $10 total
        assertEquals(new Money(16.0, "USD"), charge);
    }
    
}
