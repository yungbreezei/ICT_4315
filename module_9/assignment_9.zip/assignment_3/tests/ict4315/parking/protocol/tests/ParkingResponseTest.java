package ict4315.parking.protocol.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import ict4315.parking.protocol.ParkingResponse;

/**
 * Unit tests for the {@link ParkingResponse} class.
 * 
 * This class verifies the correctness of the constructor, 
 * string representation, and JSON serialization/deserialization 
 * of the {@code ParkingResponse} object.
 * 
 */
public class ParkingResponseTest {

    /**
     * Tests the constructor and {@code toString()} method of {@link ParkingResponse}.
     * 
     * Verifies that the status code and message are correctly stored and that
     * the string representation contains both values.
     * 
     */
    @Test
    public void testConstructorAndToString() {
        ParkingResponse response = new ParkingResponse(0, "Success");
        assertEquals(0, response.getStatusCode());
        assertEquals("Success", response.getMessage());
        assertTrue(response.toString().contains("0"));
        assertTrue(response.toString().contains("Success"));
    }

    /**
     * Tests the {@code toJson()} and {@code fromJson()} methods of {@link ParkingResponse}.
     * 
     * Serializes a {@code ParkingResponse} to JSON and then deserializes it back,
     * checking that the resulting object matches the original.
     * 
     */
    @Test
    public void testToJsonAndFromJson() {
        ParkingResponse original = new ParkingResponse(1, "Error occurred");
        String json = original.toJson();

        assertNotNull(json);
        assertTrue(json.contains("1"));
        assertTrue(json.contains("Error occurred"));

        ParkingResponse deserialized = ParkingResponse.fromJson(json);
        assertEquals(original.getStatusCode(), deserialized.getStatusCode());
        assertEquals(original.getMessage(), deserialized.getMessage());
    }
}
