package ict4315.parking.observer.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ict4315.parking.charges.factory.DefaultParkingChargeStrategyFactory;
import ict4315.parking.charges.factory.ParkingChargeStrategyFactory;
import ict4315.parking.charges.strategy.ParkingChargeStrategy;
import ict4315.parking.observer.ParkingEvent;
import ict4315.parking.observer.ParkingObserver;
import ict4315_assignment_1.Address;
import ict4315_assignment_1.Car;
import ict4315_assignment_1.CarType;
import ict4315_assignment_1.Customer;
import ict4315_assignment_1.ParkingLot;
import ict4315_assignment_1.ParkingPermit;
import ict4315_assignment_1.ParkingTransaction;
import ict4315_assignment_1.PermitManager;
import ict4315_assignment_1.TransactionManager;

class ParkingObserverTest {

    private TransactionManager transactionManager;
    private ParkingObserver parkingObserver;
    private ParkingLot lot;
    private ParkingPermit permit1;
    private ParkingPermit permit2;
    private Car car1;
    private Car car2;
    private Customer customer;

    @BeforeEach
    void setUp() {
        Address address = new Address("123 Main", "Apt 3", "Denver", "CO", "80000");

        // Create factory and transaction manager
        ParkingChargeStrategyFactory strategyFactory = new DefaultParkingChargeStrategyFactory();
        transactionManager = new TransactionManager(strategyFactory);

        // Set up ParkingLot
        lot = new ParkingLot("2345634", "Lot A", address, null, 7, 100); // Ensure lot is initialized before usage
        ParkingChargeStrategy chargeStrategy = strategyFactory.getStrategyFor(lot);
        lot.setChargeStrategy(chargeStrategy);

        customer = new Customer("14273", "John", "Doe", "555-555-5555", address);
        car1 = new Car(CarType.SUV, "XYZ-1235", customer);
        car2 = new Car(CarType.SUV, "XYZ-1236", customer);

        PermitManager permitManager = new PermitManager();
        permit1 = permitManager.register(car1);
        permit2 = permitManager.register(car2);
        
        // Setup observer with a single-lot list
        List<ParkingLot> lots = new ArrayList<>();
        lots.add(lot);
        parkingObserver = new ParkingObserver(transactionManager, lots);
        
        // Register observer to listen to this lot
        lot.addObserver(parkingObserver);
    }
    
    @Test
    void testParkingObserverCreatesTransaction() {
        // Simulate entry and exit
        lot.enter(permit1, LocalDateTime.now());

        try {
            Thread.sleep(2000); // Simulate time gap between entry and exit
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        lot.exit(permit1, LocalDateTime.now());

        // Verify a transaction was created
        List<ParkingTransaction> transactions = transactionManager.getTransactions();
        assertEquals(2, transactions.size(), "Transaction should have been created.");

        ParkingTransaction transaction = transactions.get(0);
        assertEquals(permit1, transaction.getPermit(), "Permit should match.");
        assertEquals(lot, transaction.getParkingLot(), "Lot should match.");
        assertNotNull(transaction.getEntryTime(), "Entry time should not be null.");
        assertNotNull(transaction.getExitTime(), "Exit time should not be null.");
        assertTrue(transaction.getExitTime().isAfter(transaction.getEntryTime()), 
                   "Exit should be after entry.");
    }
    
    @Test
    void testObserverIsNotifiedOnEnter() {
        // Create a subclass of ParkingObserver to monitor event notifications
        class TestObserver extends ParkingObserver {
            boolean notified = false;

            public TestObserver(TransactionManager transactionManager, List<ParkingLot> lots) {
                super(transactionManager, lots);
            }

            @Override
            public void update(ParkingEvent event) {
                if (event.isEntry()) {
                    notified = true;
                }
                super.update(event); // Optionally call super to maintain transaction creation
            }
        }

        TestObserver testObserver = new TestObserver(transactionManager, List.of(lot));
        lot.removeObserver(parkingObserver); // Clear any existing observers to isolate the test
        lot.addObserver(testObserver);

        // Trigger entry
        lot.enter(permit1, LocalDateTime.now());

        assertTrue(testObserver.notified, "Observer should be notified on entry.");
    }
    
    @Test
    void testObserverIsNotifiedOnExit() {
        // Create a subclass of ParkingObserver to monitor event notifications
        class TestObserver extends ParkingObserver {
            boolean notified = false;

            public TestObserver(TransactionManager transactionManager, List<ParkingLot> lots) {
                super(transactionManager, lots);
            }

            @Override
            public void update(ParkingEvent event) {
                if (event.isEntry()) {
                    notified = true;
                }
                super.update(event); // Optionally call super to maintain transaction creation
            }
        }

        TestObserver testObserver = new TestObserver(transactionManager, List.of(lot));
        lot.removeObserver(parkingObserver); // Clear any existing observers to isolate the test
        lot.addObserver(testObserver);

        // Trigger entry
        lot.enter(permit1, LocalDateTime.now());
        
        lot.exit(permit1, LocalDateTime.now());

        assertTrue(testObserver.notified, "Observer should be notified on exit.");
    }
    
    /*
     * Ensures that when multiple cars enter, each entry creates its own transaction
     */ 
    @Test
    void multipleEntriesAreTrackedSeparately() {
        // Simulate entries
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime entryTime1 = now;
        LocalDateTime exitTime1 = now.plusMinutes(30);

        LocalDateTime entryTime2 = now.plusMinutes(10);
        LocalDateTime exitTime2 = now.plusMinutes(45);

        lot.enter(permit1, entryTime1);  // Car 1 enters
        lot.enter(permit2, entryTime2);  // Car 2 enters

        // Simulate exits (these create transactions)
        lot.exit(permit1, exitTime1);    // Car 1 exits
        lot.exit(permit2, exitTime2);    // Car 2 exits

        // Wait for the observer to process the events
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        List<ParkingTransaction> transactions = transactionManager.getTransactions();
        assertEquals(4, transactions.size(), "There should be 2 separate transactions.");

        Set<ParkingPermit> permitsInTransactions = transactions.stream()
                .map(ParkingTransaction::getPermit)
                .collect(Collectors.toSet());

        assertTrue(permitsInTransactions.contains(permit1), "Transaction should include permit1.");
        assertTrue(permitsInTransactions.contains(permit2), "Transaction should include permit2.");

    }


    @Test
    void notifyIgnoresUntrackedLots() {
        // Create a new ParkingLot (not added to the observer's watch list)
        Address address = new Address("456 Another St", "Suite 101", "Denver", "CO", "80001");
        ParkingLot untrackedLot = new ParkingLot("2345678", "Lot B", address, null, 7, 100);

        // Simulate an entry event for a car in this untracked lot
        Car untrackedCar = new Car(CarType.SUV, "LMN1234", customer);
        ParkingPermit untrackedPermit = new PermitManager().register(untrackedCar);
        ParkingEvent untrackedEntryEvent = new ParkingEvent(untrackedPermit, untrackedLot, LocalDateTime.now(), true);

        // Notify the observer with an event from the untracked lot
        parkingObserver.update(untrackedEntryEvent);

        // Verify that no new transactions were created, since the observer isn't tracking this lot
        List<ParkingTransaction> transactions = transactionManager.getTransactions();
        assertEquals(0, transactions.size(), "No transactions should have been created for untracked lot.");
    }


}
