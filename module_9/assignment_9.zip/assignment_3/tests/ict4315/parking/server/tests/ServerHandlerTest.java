package ict4315.parking.server.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ict4315.parking.protocol.ParkingRequest;
import ict4315.parking.protocol.ParkingResponse;
import ict4315.parking.server.Server;

import java.util.Properties;
/**
 * Unit tests for the Server class to verify handling of different
 * ParkingRequest commands and input scenarios using JSON-based communication.
 */
public class ServerHandlerTest {

    private Server server; // Your server class with handlers

    /**
     * Initializes a fresh Server instance before each test.
     */
    @BeforeEach
    public void setup() {
        server = new Server();
    }

    /**
     * Tests successful handling of a "CUSTOMER" request with all required fields.
     * Expects a status code of 0 and a success message.
     */
    @Test
    public void testHandleCustomerSuccess() {
        Properties props = new Properties();
        props.setProperty("firstname", "John");
        props.setProperty("lastname", "Doe");
        props.setProperty("email", "john@example.com");

        ParkingRequest req = new ParkingRequest("CUSTOMER", props);
        ParkingResponse resp = server.handleRequest(req);

        assertEquals(0, resp.getStatusCode());
        assertEquals("Customer registered successfully", resp.getMessage());
    }

    
    /**
     * Tests handling of a "CUSTOMER" request with missing required fields.
     * Expects a status code of 1 and an error message.
     */
    @Test
    public void testHandleCustomerMissingField() {
        Properties props = new Properties();
        props.setProperty("firstname", "John");
        // Missing lastname and email

        ParkingRequest req = new ParkingRequest("CUSTOMER", props);
        ParkingResponse resp = server.handleRequest(req);

        assertEquals(1, resp.getStatusCode());
        assertTrue(resp.getMessage().contains("Missing required customer fields"));
    }

    
    /**
     * Tests successful handling of a "PARK" request with valid parameters.
     * Expects a status code of 0 and a success message.
     */
    @Test
    public void testHandleParkSuccess() {
        Properties props = new Properties();
        props.setProperty("license", "XYZ789");
        props.setProperty("lot", "LotB");

        ParkingRequest req = new ParkingRequest("PARK", props);
        ParkingResponse resp = server.handleRequest(req);

        assertEquals(0, resp.getStatusCode());
        assertEquals("Car parked successfully", resp.getMessage());
    }

    
    /**
     * Tests handling of an unknown command.
     * Expects a status code of 1 and an appropriate error message.
     */
    @Test
    public void testHandleUnknownCommand() {
        Properties props = new Properties();

        ParkingRequest req = new ParkingRequest("UNKNOWN", props);
        ParkingResponse resp = server.handleRequest(req);

        assertEquals(1, resp.getStatusCode());
        assertTrue(resp.getMessage().contains("Unknown command"));
    }
}
